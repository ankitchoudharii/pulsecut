-keepattributes *Annotation*
-keepclassmembers class com.pulsecut.pro.speech.WhistleNativeBridge {
    native <methods>;
}
-keep class com.pulsecut.pro.speech.** { *; }
-keep class com.pulsecut.pro.model.** { *; }
