#ifndef CACTUS_NEEDLE_H
#define CACTUS_NEEDLE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Cactus Compute — Needle & Whistle Speech-to-Text C API (needle.h)
 * Model: whistle.cact (16.9 MB), 16 kHz mono PCM, 80-bin Log-Mel (25ms window, 10ms hop, 250-3500 Hz)
 * 8 Encoder Simple Attention blocks + 8 Laddered Decoder blocks (--audio-depth 2..8)
 * 7 Languages: en, de, fr, es, it, nl, pl
 */

typedef struct needle_ctx needle_ctx_t;

typedef struct {
    const char* word;
    int64_t start_ms;
    int64_t end_ms;
    float probability;
} needle_word_t;

typedef struct {
    const char* language;          // NULL or "" for auto-detect, or "en","de","fr","es","it","nl","pl"
    int audio_depth;               // Decoder ladder depth (2..8, default 8)
    int beam_size;                 // Default 5 beams scored by length-normalised log prob
    int word_timestamps;           // 1 = align word start/end/prob from decoder cross-attention
    const char** keywords;         // Phrases for Aho-Corasick automaton logit biasing
    size_t num_keywords;
} needle_transcribe_opts_t;

typedef struct {
    char* text;                    // UTF-8 transcript (up to 320 tokens per 30s window)
    char language[8];              // Emitted language token ("en", "de", "fr", "es", "it", "nl", "pl")
    float ttft_ms;                 // Time to first token in milliseconds
    float decode_tps;              // Decoder tokens per second
    needle_word_t* words;          // Word-level timestamps array if word_timestamps == 1
    size_t num_words;
    int is_silence;                // 1 if clip loudness range is below silence gate threshold
} needle_transcript_result_t;

/**
 * Load a .cact model file (whistle.cact or needle3.cact).
 * Returns opaque context handle or NULL on error.
 */
needle_ctx_t* needle_load(const char* model_path, int audio_depth);

/**
 * Transcribe 16 kHz mono float32 audio samples in [-1.0, 1.0].
 * Returns non-negative token/word count on success, negative on error.
 */
int needle_transcribe(
    needle_ctx_t* ctx,
    const float* pcm_16k_mono,
    size_t num_samples,
    const needle_transcribe_opts_t* opts,
    needle_transcript_result_t* out_result
);

/**
 * Compute speech encoder embeddings (one 512-d row per 80 ms frame = 375 frames per 30s)
 * without running the decoder beam search.
 * Returns number of 80ms frames written to out_embeddings.
 */
int needle_embed(
    needle_ctx_t* ctx,
    const float* pcm_16k_mono,
    size_t num_samples,
    float* out_embeddings,
    size_t max_frames
);

/**
 * Free transcript result buffers allocated by needle_transcribe.
 */
void needle_free_result(needle_transcript_result_t* result);

/**
 * Release model context.
 */
void needle_free(needle_ctx_t* ctx);

#ifdef __cplusplus
}
#endif

#endif // CACTUS_NEEDLE_H
