#ifndef PULSECUT_WHISTLE_DSP_H
#define PULSECUT_WHISTLE_DSP_H

#include "needle.h"
#include <string>
#include <vector>
#include <unordered_map>

namespace pulsecut {
namespace whistle {

struct WordTiming {
    std::string word;
    int64_t startMs;
    int64_t endMs;
    float probability;
};

struct TranscriptOutput {
    std::string text;
    std::string language;
    float ttftMs;
    float decodeTokensPerSec;
    bool isSilence;
    std::vector<WordTiming> words;
};

/**
 * Aho-Corasick Automaton used by Whistle for O(N) keyword biasing during beam search.
 */
class AhoCorasickAutomaton {
public:
    struct Node {
        std::unordered_map<char, int> next;
        int fail = 0;
        std::vector<std::string> matchedPhrases;
        float biasBoost = 0.0f;
    };

    AhoCorasickAutomaton() { nodes_.emplace_back(); }

    void build(const std::vector<std::string>& keywords, float boost = 2.4f);
    int step(int state, char ch) const;
    float stateBoost(int state) const { return nodes_[state].biasBoost; }
    const std::vector<std::string>& matchesAt(int state) const { return nodes_[state].matchedPhrases; }

private:
    std::vector<Node> nodes_;
};

/**
 * Whistle 16 kHz Audio Front-End & Runtime Engine Wrapper:
 * - Resamples any PCM stream to 16,000 Hz mono float32
 * - Computes 80-bin Log-Mel Spectrogram (25 ms window = 400 samples, 10 ms hop = 160 samples, 250-3500 Hz)
 * - Evaluates loudness range for Whistle's Silence Gate
 * - Calls libneedle (needle_load / needle_transcribe / needle_embed) if linked or dlopen'd,
 *   or executes deterministic on-device VAD + energy-aligned word timestamping.
 */
class WhistleEngineInstance {
public:
    WhistleEngineInstance(const std::string& modelPath, int audioDepth);
    ~WhistleEngineInstance();

    bool isModelFileLoaded() const { return modelFileValid_; }
    int audioDepth() const { return audioDepth_; }
    size_t modelSizeBytes() const { return modelSizeBytes_; }

    static std::vector<float> resampleTo16kMono(
        const int16_t* pcmData,
        size_t numFrames,
        int inputSampleRate,
        int channels
    );

    static bool checkSilenceGate(const float* samples16k, size_t count, float* outDbRange = nullptr);

    static std::vector<float> computeLogMel80(
        const float* samples16k,
        size_t count,
        int* outNumFrames
    );

    TranscriptOutput transcribeWindowed(
        const float* samples16k,
        size_t numSamples,
        const std::string& forcedLanguage,
        bool wordTimestamps,
        int beamSize,
        const std::vector<std::string>& keywords,
        const std::string& referenceTranscriptHint = ""
    );

    std::vector<float> computeSpeechEmbeddings80ms(
        const float* samples16k,
        size_t numSamples
    );

private:
    std::string modelPath_;
    int audioDepth_;
    bool modelFileValid_ = false;
    size_t modelSizeBytes_ = 0;
    void* dlHandle_ = nullptr;
    needle_ctx_t* nativeCtx_ = nullptr;

    // Dynamic symbol pointers if libneedle.so is present at runtime
    using fn_needle_load = needle_ctx_t* (*)(const char*, int);
    using fn_needle_transcribe = int (*)(needle_ctx_t*, const float*, size_t, const needle_transcribe_opts_t*, needle_transcript_result_t*);
    using fn_needle_embed = int (*)(needle_ctx_t*, const float*, size_t, float*, size_t);
    using fn_needle_free_result = void (*)(needle_transcript_result_t*);
    using fn_needle_free = void (*)(needle_ctx_t*);

    fn_needle_load symLoad_ = nullptr;
    fn_needle_transcribe symTranscribe_ = nullptr;
    fn_needle_embed symEmbed_ = nullptr;
    fn_needle_free_result symFreeResult_ = nullptr;
    fn_needle_free symFree_ = nullptr;
};

} // namespace whistle
} // namespace pulsecut

#endif // PULSECUT_WHISTLE_DSP_H
