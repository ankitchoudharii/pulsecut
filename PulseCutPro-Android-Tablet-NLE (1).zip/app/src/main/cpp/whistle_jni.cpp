#include <jni.h>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include "whistle_dsp.h"

using pulsecut::whistle::WhistleEngineInstance;
using pulsecut::whistle::TranscriptOutput;

namespace {
std::string escapeJson(const std::string& s) {
    std::ostringstream o;
    for (char c : s) {
        switch (c) {
            case '"': o << "\\\""; break;
            case '\\': o << "\\\\"; break;
            case '\b': o << "\\b"; break;
            case '\f': o << "\\f"; break;
            case '\n': o << "\\n"; break;
            case '\r': o << "\\r"; break;
            case '\t': o << "\\t"; break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    o << "\\u" << std::hex << std::setw(4) << std::setfill('0') << static_cast<int>(c);
                } else {
                    o << c;
                }
        }
    }
    return o.str();
}
} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_pulsecut_pro_speech_WhistleNativeBridge_nativeInit(
    JNIEnv* env,
    jobject /* thiz */,
    jstring modelPath,
    jint audioDepth
) {
    const char* pathChars = env->GetStringUTFChars(modelPath, nullptr);
    std::string pathStr(pathChars ? pathChars : "");
    if (pathChars) env->ReleaseStringUTFChars(modelPath, pathChars);

    auto* instance = new WhistleEngineInstance(pathStr, static_cast<int>(audioDepth));
    return reinterpret_cast<jlong>(instance);
}

JNIEXPORT void JNICALL
Java_com_pulsecut_pro_speech_WhistleNativeBridge_nativeRelease(
    JNIEnv* /* env */,
    jobject /* thiz */,
    jlong handle
) {
    auto* instance = reinterpret_cast<WhistleEngineInstance*>(handle);
    delete instance;
}

JNIEXPORT jfloatArray JNICALL
Java_com_pulsecut_pro_speech_WhistleNativeBridge_nativeResampleTo16kMono(
    JNIEnv* env,
    jobject /* thiz */,
    jshortArray inputPcm16,
    jint inputSampleRate,
    jint channels
) {
    if (!inputPcm16 || channels <= 0) {
        return env->NewFloatArray(0);
    }
    jsize totalShorts = env->GetArrayLength(inputPcm16);
    size_t numFrames = static_cast<size_t>(totalShorts / channels);
    jshort* rawShorts = env->GetShortArrayElements(inputPcm16, nullptr);

    std::vector<float> resampled = WhistleEngineInstance::resampleTo16kMono(
        reinterpret_cast<const int16_t*>(rawShorts),
        numFrames,
        static_cast<int>(inputSampleRate),
        static_cast<int>(channels)
    );

    env->ReleaseShortArrayElements(inputPcm16, rawShorts, JNI_ABORT);

    jfloatArray outArr = env->NewFloatArray(static_cast<jsize>(resampled.size()));
    if (!resampled.empty()) {
        env->SetFloatArrayRegion(outArr, 0, static_cast<jsize>(resampled.size()), resampled.data());
    }
    return outArr;
}

JNIEXPORT jstring JNICALL
Java_com_pulsecut_pro_speech_WhistleNativeBridge_nativeTranscribePcm16k(
    JNIEnv* env,
    jobject /* thiz */,
    jlong handle,
    jfloatArray pcm16kMono,
    jstring language,
    jboolean wordTimestamps,
    jint beamSize,
    jobjectArray keywords,
    jstring transcriptHint
) {
    auto* instance = reinterpret_cast<WhistleEngineInstance*>(handle);
    if (!instance || !pcm16kMono) {
        return env->NewStringUTF("{\"text\":\"\",\"language\":\"\",\"isSilence\":true,\"words\":[]}");
    }

    jsize numSamples = env->GetArrayLength(pcm16kMono);
    jfloat* samplesPtr = env->GetFloatArrayElements(pcm16kMono, nullptr);

    const char* langChars = language ? env->GetStringUTFChars(language, nullptr) : nullptr;
    std::string langStr(langChars ? langChars : "");
    if (langChars) env->ReleaseStringUTFChars(language, langChars);

    const char* hintChars = transcriptHint ? env->GetStringUTFChars(transcriptHint, nullptr) : nullptr;
    std::string hintStr(hintChars ? hintChars : "");
    if (hintChars) env->ReleaseStringUTFChars(transcriptHint, hintChars);

    std::vector<std::string> kwList;
    if (keywords) {
        jsize kwCount = env->GetArrayLength(keywords);
        for (jsize i = 0; i < kwCount; ++i) {
            auto jkw = static_cast<jstring>(env->GetObjectArrayElement(keywords, i));
            if (jkw) {
                const char* kChars = env->GetStringUTFChars(jkw, nullptr);
                if (kChars) {
                    kwList.emplace_back(kChars);
                    env->ReleaseStringUTFChars(jkw, kChars);
                }
                env->DeleteLocalRef(jkw);
            }
        }
    }

    TranscriptOutput result = instance->transcribeWindowed(
        samplesPtr,
        static_cast<size_t>(numSamples),
        langStr,
        wordTimestamps == JNI_TRUE,
        static_cast<int>(beamSize),
        kwList,
        hintStr
    );

    env->ReleaseFloatArrayElements(pcm16kMono, samplesPtr, JNI_ABORT);

    std::ostringstream json;
    json << std::fixed << std::setprecision(2);
    json << "{"
         << "\"text\":\"" << escapeJson(result.text) << "\","
         << "\"language\":\"" << escapeJson(result.language) << "\","
         << "\"ttftMs\":" << result.ttftMs << ","
         << "\"decodeTokensPerSec\":" << result.decodeTokensPerSec << ","
         << "\"isSilence\":" << (result.isSilence ? "true" : "false") << ","
         << "\"audioDepth\":" << instance->audioDepth() << ","
         << "\"words\":[";

    for (size_t i = 0; i < result.words.size(); ++i) {
        if (i > 0) json << ",";
        const auto& w = result.words[i];
        json << "{"
             << "\"word\":\"" << escapeJson(w.word) << "\","
             << "\"startMs\":" << w.startMs << ","
             << "\"endMs\":" << w.endMs << ","
             << "\"probability\":" << std::setprecision(3) << w.probability
             << "}";
    }
    json << "]}";

    return env->NewStringUTF(json.str().c_str());
}

JNIEXPORT jfloatArray JNICALL
Java_com_pulsecut_pro_speech_WhistleNativeBridge_nativeEmbedPcm16k(
    JNIEnv* env,
    jobject /* thiz */,
    jlong handle,
    jfloatArray pcm16kMono
) {
    auto* instance = reinterpret_cast<WhistleEngineInstance*>(handle);
    if (!instance || !pcm16kMono) {
        return env->NewFloatArray(0);
    }
    jsize numSamples = env->GetArrayLength(pcm16kMono);
    jfloat* samplesPtr = env->GetFloatArrayElements(pcm16kMono, nullptr);

    std::vector<float> emb = instance->computeSpeechEmbeddings80ms(
        samplesPtr,
        static_cast<size_t>(numSamples)
    );

    env->ReleaseFloatArrayElements(pcm16kMono, samplesPtr, JNI_ABORT);

    jfloatArray outArr = env->NewFloatArray(static_cast<jsize>(emb.size()));
    if (!emb.empty()) {
        env->SetFloatArrayRegion(outArr, 0, static_cast<jsize>(emb.size()), emb.data());
    }
    return outArr;
}

} // extern "C"
