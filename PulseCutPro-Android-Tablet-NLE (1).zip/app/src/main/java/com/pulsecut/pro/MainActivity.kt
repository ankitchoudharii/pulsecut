package com.pulsecut.pro

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import com.pulsecut.pro.shortcuts.PremiereShortcutManager
import com.pulsecut.pro.ui.TabletWorkspaceScreen
import com.pulsecut.pro.viewmodel.EditorViewModel

class MainActivity : ComponentActivity() {

    private val editorViewModel: EditorViewModel by viewModels()
    private val shortcutManager = PremiereShortcutManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var isTextInputFocused by remember { mutableStateOf(false) }

            val mediaPickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.GetContent()
            ) { uri: Uri? ->
                if (uri != null) {
                    val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Tablet_Clip.mp4"
                    editorViewModel.importExternalMediaUri(uri.toString(), name)
                }
            }

            val nleColorScheme = darkColorScheme(
                primary = Color(0xFF6C5CE7),
                secondary = Color(0xFF00D2FF),
                tertiary = Color(0xFF00FF88),
                background = Color(0xFF0D0F14),
                surface = Color(0xFF151922)
            )

            MaterialTheme(colorScheme = nleColorScheme) {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .onPreviewKeyEvent { keyEvent ->
                            val command = shortcutManager.onHardwareKeyEvent(
                                event = keyEvent,
                                isTextInputFocused = isTextInputFocused
                            )
                            if (command != null) {
                                editorViewModel.executePremiereCommand(command)
                                true
                            } else {
                                false
                            }
                        },
                    color = Color(0xFF0D0F14)
                ) {
                    TabletWorkspaceScreen(
                        viewModel = editorViewModel,
                        onPickExternalMedia = { mediaPickerLauncher.launch("video/*") },
                        onTextFocusChanged = { focused -> isTextInputFocused = focused }
                    )
                }
            }
        }
    }
}
