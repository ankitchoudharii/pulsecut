package com.pulsecut.pro.model

import kotlinx.serialization.Serializable
import kotlin.math.roundToInt

/**
 * Multi-Aspect Ratio Engine for PulseCut Pro on Android Tablets.
 * Supports instant switching between Landscape, Vertical (Reels/Shorts), Square, Portrait,
 * Cinema Ultrawide, and Classic 4:3 with automatic safe-zone overlays and export dimensions.
 */
@Serializable
enum class AspectRatioPreset(
    val id: String,
    val label: String,
    val subtitle: String,
    val widthUnits: Int,
    val heightUnits: Int,
    val defaultCaptionNormalizedY: Float,
    val showSocialUiSafeZones: Boolean
) {
    RATIO_16_9(
        id = "16:9",
        label = "16:9",
        subtitle = "YouTube / Tablet Landscape",
        widthUnits = 16,
        heightUnits = 9,
        defaultCaptionNormalizedY = 0.84f,
        showSocialUiSafeZones = false
    ),
    RATIO_9_16(
        id = "9:16",
        label = "9:16",
        subtitle = "Reels / Shorts / TikTok",
        widthUnits = 9,
        heightUnits = 16,
        defaultCaptionNormalizedY = 0.72f,
        showSocialUiSafeZones = true
    ),
    RATIO_1_1(
        id = "1:1",
        label = "1:1",
        subtitle = "Square Feed / Carousel",
        widthUnits = 1,
        heightUnits = 1,
        defaultCaptionNormalizedY = 0.82f,
        showSocialUiSafeZones = false
    ),
    RATIO_4_5(
        id = "4:5",
        label = "4:5",
        subtitle = "Portrait Social Feed",
        widthUnits = 4,
        heightUnits = 5,
        defaultCaptionNormalizedY = 0.78f,
        showSocialUiSafeZones = true
    ),
    RATIO_21_9(
        id = "21:9",
        label = "21:9",
        subtitle = "Cinema Ultrawide",
        widthUnits = 21,
        heightUnits = 9,
        defaultCaptionNormalizedY = 0.86f,
        showSocialUiSafeZones = false
    ),
    RATIO_4_3(
        id = "4:3",
        label = "4:3",
        subtitle = "Classic Tablet / IMAX",
        widthUnits = 4,
        heightUnits = 3,
        defaultCaptionNormalizedY = 0.83f,
        showSocialUiSafeZones = false
    );

    val aspectRatioFloat: Float
        get() = widthUnits.toFloat() / heightUnits.toFloat()

    val isVertical: Boolean
        get() = heightUnits > widthUnits

    /**
     * Computes even-numbered pixel dimensions (required by Android MediaCodec H.264/HEVC encoders)
     * for a target resolution tier (e.g. 720p, 1080p, 2160p 4K).
     */
    fun computeExportDimensions(shortEdgePx: Int = 1080): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (widthUnits >= heightUnits) {
            h = shortEdgePx
            w = ((shortEdgePx.toFloat() * widthUnits) / heightUnits).roundToInt()
        } else {
            w = shortEdgePx
            h = ((shortEdgePx.toFloat() * heightUnits) / widthUnits).roundToInt()
        }
        // Round to multiples of 2 for hardware MediaCodec compatibility
        val evenW = if (w % 2 == 0) w else w + 1
        val evenH = if (h % 2 == 0) h else h + 1
        return evenW to evenH
    }
}

/**
 * Defines how source clips with different native aspect ratios fit inside the sequence canvas.
 */
@Serializable
enum class CanvasScalingMode(val label: String, val description: String) {
    FIT_LETTERBOX("Fit (Letterbox)", "Preserves full frame with studio bars"),
    FILL_CROP("Fill & Crop", "Scales to fill entire aspect ratio canvas"),
    BLUR_BACKDROP("Blurred Backdrop", "Fills background with Gaussian-blurred duplicate"),
    STRETCH("Stretch to Canvas", "Stretches media to match canvas edges")
}

@Serializable
enum class ExportResolutionTier(val label: String, val shortEdgePx: Int, val bitrateMbps: Int) {
    HD_720P("720p HD", 720, 8),
    FHD_1080P("1080p Full HD", 1080, 16),
    QHD_1440P("1440p 2K", 1440, 24),
    UHD_4K("2160p 4K UHD", 2160, 42)
}
