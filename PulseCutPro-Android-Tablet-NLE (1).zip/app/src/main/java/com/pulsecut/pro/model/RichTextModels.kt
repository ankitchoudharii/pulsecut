package com.pulsecut.pro.model

import com.pulsecut.pro.speech.WhistleWordTimestamp
import kotlinx.serialization.Serializable

@Serializable
enum class EditorFontFamily(val displayName: String, val systemFamilyName: String) {
    INTER_SANS("Inter / Modern Sans", "sans-serif"),
    MONTSERRAT_HEAVY("Montserrat Black", "sans-serif-black"),
    BEBAS_CONDENSED("Bebas Condensed", "sans-serif-condensed"),
    PLAYFAIR_SERIF("Playfair Editorial", "serif"),
    JETBRAINS_MONO("JetBrains Code Mono", "monospace"),
    CURSIVE_SCRIPT("Studio Script", "cursive")
}

@Serializable
enum class TextCaseMode(val label: String) {
    ORIGINAL("Aa"),
    UPPERCASE("AA"),
    LOWERCASE("aa"),
    TITLE_CASE("Title")
}

@Serializable
enum class TextAlignMode(val label: String) {
    LEFT("Left"),
    CENTER("Center"),
    RIGHT("Right")
}

@Serializable
enum class TextFillType(val label: String) {
    SOLID("Solid"),
    LINEAR_GRADIENT("Linear Gradient"),
    RADIAL_GRADIENT("Radial Gradient")
}

@Serializable
enum class TextAnimationPreset(val label: String, val description: String) {
    NONE("Static", "No entrance or per-word motion"),
    KARAOKE_POP("Word Pop", "Scales & highlights active word via Whistle timestamps"),
    KARAOKE_PILL_SWEEP("Sliding Pill", "Sweeps rounded pill behind active spoken word"),
    TYPEWRITER("Typewriter", "Reveals characters progressively over time"),
    FADE_UP_WORDS("Fade Up", "Smooth upward entrance with opacity ramp"),
    NEON_FLICKER("Neon Pulse", "Pulses outer glow intensity with audio beat"),
    SLIDE_ELASTIC("Elastic Slide", "Overshoots X position with spring damping")
}

@Serializable
enum class CaptionStylePreset(
    val displayName: String,
    val badge: String,
    val description: String
) {
    HORMOZI_BOLD("Alex Bold Pop", "POP", "Heavy uppercase yellow/green active word pop with thick black stroke"),
    KARAOKE_PILL("Dynamic Pill", "PILL", "Crisp white text with rounded purple pill sweeping behind spoken word"),
    NETFLIX_CLEAN("Cinema Subtitle", "PRO", "Clean translucent dark box with broadcast-grade legibility"),
    NEON_GLOW("Cyber Neon", "GLOW", "Electric cyan gradient fill with multi-pass outer neon shadow"),
    CREATOR_MINIMAL("Editorial Serif", "SERIF", "Warm cream serif typography with subtle drop shadow"),
    YELLOW_BROADCAST("Documentary Yellow", "DOC", "Classic golden-yellow broadcast captions with black outline")
}

@Serializable
data class TextKeyframe(
    val timeOffsetMs: Long,
    val normalizedX: Float = 0.5f,
    val normalizedY: Float = 0.5f,
    val scale: Float = 1.0f,
    val rotationDeg: Float = 0.0f,
    val opacity: Float = 1.0f
)

/**
 * Full Typography & Multi-Layer Visual Styling model for Text & Captions.
 */
@Serializable
data class RichTextSpec(
    val text: String = "DOUBLE TAP OR PRESS 'T' TO EDIT",
    val fontFamily: EditorFontFamily = EditorFontFamily.MONTSERRAT_HEAVY,
    val customFontUri: String? = null,
    val fontSizeSp: Float = 38f,
    val fontWeight: Int = 800, // 100..900
    val isItalic: Boolean = false,
    val isUnderline: Boolean = false,
    val isStrikethrough: Boolean = false,
    val caseMode: TextCaseMode = TextCaseMode.ORIGINAL,
    val letterSpacingEm: Float = 0.02f,
    val lineHeightMultiplier: Float = 1.18f,
    val textAlign: TextAlignMode = TextAlignMode.CENTER,

    // Canvas Normalized Position (0.0 .. 1.0 relative to active AspectRatio canvas)
    val normalizedX: Float = 0.5f,
    val normalizedY: Float = 0.5f,
    val scale: Float = 1.0f,
    val rotationDeg: Float = 0.0f,
    val opacity: Float = 1.0f,

    // Fill & Gradient
    val fillType: TextFillType = TextFillType.SOLID,
    val primaryColorArgb: Long = 0xFFFFFFFF,
    val secondaryColorArgb: Long = 0xFF00D2FF,
    val gradientAngleDeg: Float = 45f,

    // Primary & Outer Strokes
    val strokeEnabled: Boolean = true,
    val strokeColorArgb: Long = 0xFF000000,
    val strokeWidthPx: Float = 8f,
    val outerStrokeEnabled: Boolean = false,
    val outerStrokeColorArgb: Long = 0xFF6C5CE7,
    val outerStrokeWidthPx: Float = 14f,

    // Drop Shadow / Neon Glow
    val shadowEnabled: Boolean = true,
    val shadowColorArgb: Long = 0xCC000000,
    val shadowBlurPx: Float = 12f,
    val shadowOffsetX: Float = 0f,
    val shadowOffsetY: Float = 5f,

    // Background Box / Pill
    val backgroundEnabled: Boolean = false,
    val backgroundColorArgb: Long = 0xCC10141D,
    val backgroundCornerRadiusPx: Float = 22f,
    val backgroundPaddingHPx: Float = 28f,
    val backgroundPaddingVPx: Float = 14f,

    // Motion & Keyframes
    val animationPreset: TextAnimationPreset = TextAnimationPreset.FADE_UP_WORDS,
    val animationInDurationMs: Long = 280L,
    val animationOutDurationMs: Long = 220L,
    val keyframes: List<TextKeyframe> = emptyList()
) {
    fun formattedText(): String {
        return when (caseMode) {
            TextCaseMode.ORIGINAL -> text
            TextCaseMode.UPPERCASE -> text.uppercase()
            TextCaseMode.LOWERCASE -> text.lowercase()
            TextCaseMode.TITLE_CASE -> text.split(" ").joinToString(" ") { word ->
                word.lowercase().replaceFirstChar { it.uppercase() }
            }
        }
    }
}

/**
 * Word-level synchronized Caption Segment powered by Cactus Whistle word timestamps.
 */
@Serializable
data class CaptionSegmentSpec(
    val rawText: String,
    val language: String = "en",
    val words: List<WhistleWordTimestamp> = emptyList(),
    val stylePreset: CaptionStylePreset = CaptionStylePreset.HORMOZI_BOLD,
    val activeWordHighlightColorArgb: Long = 0xFF00FF88,
    val activeWordPillColorArgb: Long = 0xFF6C5CE7,
    val activeWordScalePop: Float = 1.16f,
    val showActiveWordPill: Boolean = true,
    val maxWordsPerLine: Int = 4,
    val richStyle: RichTextSpec = RichTextSpec(
        text = rawText,
        fontFamily = EditorFontFamily.MONTSERRAT_HEAVY,
        fontSizeSp = 36f,
        fontWeight = 900,
        caseMode = TextCaseMode.UPPERCASE,
        normalizedX = 0.5f,
        normalizedY = 0.82f,
        primaryColorArgb = 0xFFFFFFFF,
        strokeEnabled = true,
        strokeColorArgb = 0xFF000000,
        strokeWidthPx = 10f,
        shadowEnabled = true,
        shadowColorArgb = 0xDD000000,
        shadowBlurPx = 14f,
        animationPreset = TextAnimationPreset.KARAOKE_POP
    )
) {
    companion object {
        fun fromPreset(
            rawText: String,
            language: String,
            words: List<WhistleWordTimestamp>,
            preset: CaptionStylePreset,
            normalizedY: Float = 0.82f
        ): CaptionSegmentSpec {
            return when (preset) {
                CaptionStylePreset.HORMOZI_BOLD -> CaptionSegmentSpec(
                    rawText = rawText,
                    language = language,
                    words = words,
                    stylePreset = preset,
                    activeWordHighlightColorArgb = 0xFF00FF88,
                    activeWordPillColorArgb = 0xFF000000,
                    activeWordScalePop = 1.18f,
                    showActiveWordPill = false,
                    maxWordsPerLine = 4,
                    richStyle = RichTextSpec(
                        text = rawText,
                        fontFamily = EditorFontFamily.MONTSERRAT_HEAVY,
                        fontSizeSp = 38f,
                        fontWeight = 900,
                        caseMode = TextCaseMode.UPPERCASE,
                        normalizedX = 0.5f,
                        normalizedY = normalizedY,
                        primaryColorArgb = 0xFFFFFFFF,
                        strokeEnabled = true,
                        strokeColorArgb = 0xFF000000,
                        strokeWidthPx = 11f,
                        shadowEnabled = true,
                        shadowColorArgb = 0xEE000000,
                        shadowBlurPx = 16f,
                        animationPreset = TextAnimationPreset.KARAOKE_POP
                    )
                )

                CaptionStylePreset.KARAOKE_PILL -> CaptionSegmentSpec(
                    rawText = rawText,
                    language = language,
                    words = words,
                    stylePreset = preset,
                    activeWordHighlightColorArgb = 0xFFFFFFFF,
                    activeWordPillColorArgb = 0xFF6C5CE7,
                    activeWordScalePop = 1.08f,
                    showActiveWordPill = true,
                    maxWordsPerLine = 5,
                    richStyle = RichTextSpec(
                        text = rawText,
                        fontFamily = EditorFontFamily.INTER_SANS,
                        fontSizeSp = 34f,
                        fontWeight = 800,
                        caseMode = TextCaseMode.ORIGINAL,
                        normalizedX = 0.5f,
                        normalizedY = normalizedY,
                        primaryColorArgb = 0xFFEAECEF,
                        strokeEnabled = true,
                        strokeColorArgb = 0xFF0D0F14,
                        strokeWidthPx = 6f,
                        backgroundEnabled = true,
                        backgroundColorArgb = 0xAA0D0F14,
                        backgroundCornerRadiusPx = 24f,
                        animationPreset = TextAnimationPreset.KARAOKE_PILL_SWEEP
                    )
                )

                CaptionStylePreset.NETFLIX_CLEAN -> CaptionSegmentSpec(
                    rawText = rawText,
                    language = language,
                    words = words,
                    stylePreset = preset,
                    activeWordHighlightColorArgb = 0xFFFFFFFF,
                    activeWordPillColorArgb = 0x00000000,
                    activeWordScalePop = 1.0f,
                    showActiveWordPill = false,
                    maxWordsPerLine = 7,
                    richStyle = RichTextSpec(
                        text = rawText,
                        fontFamily = EditorFontFamily.INTER_SANS,
                        fontSizeSp = 30f,
                        fontWeight = 600,
                        caseMode = TextCaseMode.ORIGINAL,
                        normalizedX = 0.5f,
                        normalizedY = normalizedY,
                        primaryColorArgb = 0xFFFFFFFF,
                        strokeEnabled = true,
                        strokeColorArgb = 0xCC000000,
                        strokeWidthPx = 4f,
                        backgroundEnabled = true,
                        backgroundColorArgb = 0xB8000000,
                        backgroundCornerRadiusPx = 10f,
                        animationPreset = TextAnimationPreset.NONE
                    )
                )

                CaptionStylePreset.NEON_GLOW -> CaptionSegmentSpec(
                    rawText = rawText,
                    language = language,
                    words = words,
                    stylePreset = preset,
                    activeWordHighlightColorArgb = 0xFF00D2FF,
                    activeWordPillColorArgb = 0x6600D2FF,
                    activeWordScalePop = 1.14f,
                    showActiveWordPill = true,
                    maxWordsPerLine = 4,
                    richStyle = RichTextSpec(
                        text = rawText,
                        fontFamily = EditorFontFamily.BEBAS_CONDENSED,
                        fontSizeSp = 42f,
                        fontWeight = 800,
                        caseMode = TextCaseMode.UPPERCASE,
                        normalizedX = 0.5f,
                        normalizedY = normalizedY,
                        fillType = TextFillType.LINEAR_GRADIENT,
                        primaryColorArgb = 0xFFFFFFFF,
                        secondaryColorArgb = 0xFF00D2FF,
                        strokeEnabled = true,
                        strokeColorArgb = 0xFF090D16,
                        strokeWidthPx = 6f,
                        shadowEnabled = true,
                        shadowColorArgb = 0xFF00D2FF,
                        shadowBlurPx = 24f,
                        animationPreset = TextAnimationPreset.NEON_FLICKER
                    )
                )

                CaptionStylePreset.CREATOR_MINIMAL -> CaptionSegmentSpec(
                    rawText = rawText,
                    language = language,
                    words = words,
                    stylePreset = preset,
                    activeWordHighlightColorArgb = 0xFFFFEAA7,
                    activeWordPillColorArgb = 0x00000000,
                    activeWordScalePop = 1.06f,
                    showActiveWordPill = false,
                    maxWordsPerLine = 5,
                    richStyle = RichTextSpec(
                        text = rawText,
                        fontFamily = EditorFontFamily.PLAYFAIR_SERIF,
                        fontSizeSp = 34f,
                        fontWeight = 700,
                        isItalic = true,
                        caseMode = TextCaseMode.ORIGINAL,
                        normalizedX = 0.5f,
                        normalizedY = normalizedY,
                        primaryColorArgb = 0xFFFDFBF7,
                        strokeEnabled = false,
                        shadowEnabled = true,
                        shadowColorArgb = 0xCC000000,
                        shadowBlurPx = 12f,
                        animationPreset = TextAnimationPreset.FADE_UP_WORDS
                    )
                )

                CaptionStylePreset.YELLOW_BROADCAST -> CaptionSegmentSpec(
                    rawText = rawText,
                    language = language,
                    words = words,
                    stylePreset = preset,
                    activeWordHighlightColorArgb = 0xFFFFD32A,
                    activeWordPillColorArgb = 0x00000000,
                    activeWordScalePop = 1.08f,
                    showActiveWordPill = false,
                    maxWordsPerLine = 6,
                    richStyle = RichTextSpec(
                        text = rawText,
                        fontFamily = EditorFontFamily.INTER_SANS,
                        fontSizeSp = 33f,
                        fontWeight = 800,
                        caseMode = TextCaseMode.ORIGINAL,
                        normalizedX = 0.5f,
                        normalizedY = normalizedY,
                        primaryColorArgb = 0xFFFFD32A,
                        strokeEnabled = true,
                        strokeColorArgb = 0xFF000000,
                        strokeWidthPx = 8f,
                        shadowEnabled = true,
                        shadowColorArgb = 0xDD000000,
                        shadowBlurPx = 10f,
                        animationPreset = TextAnimationPreset.KARAOKE_POP
                    )
                )
            }
        }
    }
}
