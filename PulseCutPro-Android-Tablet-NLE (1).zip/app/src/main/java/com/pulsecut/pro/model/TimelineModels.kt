package com.pulsecut.pro.model

import kotlinx.serialization.Serializable

/**
 * Premiere Pro Non-Linear Editing Tools mapped to hardware keyboard shortcuts.
 */
@Serializable
enum class EditTool(
    val shortcutKey: String,
    val displayName: String,
    val description: String
) {
    SELECTION_V("V", "Selection Tool", "Standard clip selection, move, and edge trim"),
    TRACK_SELECT_A("A", "Track Select Forward", "Selects all clips to the right on unlocked tracks"),
    RIPPLE_EDIT_B("B", "Ripple Edit Tool", "Trims clip edge and automatically ripples downstream clips"),
    ROLLING_EDIT_N("N", "Rolling Edit Tool", "Moves the edit cut point between two adjacent clips"),
    RATE_STRETCH_R("R", "Rate Stretch Tool", "Speeds up or slows down clip to fit target duration"),
    RAZOR_C("C", "Razor (Blade) Tool", "Splits clip at cursor or playhead position"),
    SLIP_Y("Y", "Slip Tool", "Shifts source In/Out points while preserving clip duration & position"),
    SLIDE_U("U", "Slide Tool", "Moves clip along timeline while trimming adjacent neighbor clips"),
    TYPE_T("T", "Type Tool", "Creates or edits rich text layers directly on the Program Monitor"),
    HAND_H("H", "Hand Tool", "Pans the timeline or zoomed Program Monitor canvas"),
    ZOOM_Z("Z", "Zoom Tool", "Zooms timeline time-scale in or out")
}

@Serializable
enum class TrackType(val badgePrefix: String, val defaultColorArgb: Long) {
    VIDEO("V", 0xFF3B82F6),
    TEXT("T", 0xFFA855F7),
    CAPTION("C", 0xFF10B981),
    AUDIO("A", 0xFF06B6D4)
}

@Serializable
data class ClipTransform(
    val positionX: Float = 0f,
    val positionY: Float = 0f,
    val scale: Float = 1.0f,
    val rotationDeg: Float = 0f,
    val anchorX: Float = 0.5f,
    val anchorY: Float = 0.5f,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
    val scalingOverride: CanvasScalingMode? = null
)

@Serializable
data class ColorGradeConfig(
    val exposure: Float = 0f,      // -2.0 .. +2.0
    val contrast: Float = 1.0f,    // 0.5 .. 1.8
    val saturation: Float = 1.0f,  // 0.0 .. 2.0
    val temperature: Float = 0f,   // -100 .. +100
    val tint: Float = 0f,          // -100 .. +100
    val highlights: Float = 0f,    // -100 .. +100
    val shadows: Float = 0f,       // -100 .. +100
    val vignette: Float = 0f       // 0.0 .. 1.0
)

@Serializable
data class SequenceMarker(
    val id: String,
    val timeMs: Long,
    val label: String,
    val colorArgb: Long = 0xFF00D2FF
)

@Serializable
data class TimelineClip(
    val id: String,
    val name: String,
    val trackId: String,
    val trackType: TrackType,
    val mediaUri: String? = null,
    val timelineStartMs: Long,
    val durationMs: Long,
    val sourceInMs: Long = 0L,
    val sourceDurationMs: Long = 30_000L,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val opacity: Float = 1.0f,
    val clipColorArgb: Long = trackType.defaultColorArgb,
    val transform: ClipTransform = ClipTransform(),
    val colorGrade: ColorGradeConfig = ColorGradeConfig(),
    val textData: RichTextSpec? = null,
    val captionData: CaptionSegmentSpec? = null,
    val waveformPeaks: List<Float> = emptyList(),
    val spokenTranscriptHint: String = ""
) {
    val timelineEndMs: Long
        get() = timelineStartMs + durationMs

    fun containsTime(timeMs: Long): Boolean =
        timeMs >= timelineStartMs && timeMs < timelineEndMs
}

@Serializable
data class TimelineTrack(
    val id: String,
    val name: String,
    val type: TrackType,
    val isMuted: Boolean = false,
    val isSolo: Boolean = false,
    val isLocked: Boolean = false,
    val isVisible: Boolean = true,
    val isTargetTrack: Boolean = true,
    val heightDp: Int = 58,
    val clips: List<TimelineClip> = emptyList()
)

@Serializable
data class SourceMonitorAsset(
    val id: String,
    val name: String,
    val mediaUri: String? = null,
    val durationMs: Long = 12_000L,
    val inPointMs: Long = 0L,
    val outPointMs: Long = 12_000L,
    val nativeAspect: AspectRatioPreset = AspectRatioPreset.RATIO_16_9,
    val defaultTranscriptHint: String = ""
)

@Serializable
data class ProjectSequence(
    val id: String = "seq_main",
    val name: String = "Tablet Master Sequence",
    val aspectRatio: AspectRatioPreset = AspectRatioPreset.RATIO_16_9,
    val canvasScalingMode: CanvasScalingMode = CanvasScalingMode.BLUR_BACKDROP,
    val fps: Int = 30,
    val exportResolution: ExportResolutionTier = ExportResolutionTier.FHD_1080P,
    val backgroundColorArgb: Long = 0xFF090B10,
    val showSafeZoneGuides: Boolean = true,
    val magneticSnapEnabled: Boolean = true,
    val autoRippleEnabled: Boolean = false,
    val inPointMs: Long? = null,
    val outPointMs: Long? = null,
    val markers: List<SequenceMarker> = emptyList(),
    val tracks: List<TimelineTrack> = emptyList()
) {
    val totalDurationMs: Long
        get() = tracks.flatMap { it.clips }
            .maxOfOrNull { it.timelineEndMs }
            ?.coerceAtLeast(15_000L) ?: 15_000L

    val frameDurationMs: Long
        get() = (1000L / fps.coerceAtLeast(1)).coerceAtLeast(16L)
}
