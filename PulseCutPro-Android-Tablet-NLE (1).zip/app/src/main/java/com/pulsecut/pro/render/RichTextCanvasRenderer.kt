package com.pulsecut.pro.render

import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import com.pulsecut.pro.model.AspectRatioPreset
import com.pulsecut.pro.model.CanvasScalingMode
import com.pulsecut.pro.model.CaptionSegmentSpec
import com.pulsecut.pro.model.RichTextSpec
import com.pulsecut.pro.model.TextAlignMode
import com.pulsecut.pro.model.TextAnimationPreset
import com.pulsecut.pro.model.TextFillType
import com.pulsecut.pro.model.TimelineClip
import com.pulsecut.pro.model.TrackType
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Shared WYSIWYG Frame & Typography Compositor used by both the live Tablet Program Monitor
 * and the hardware MP4 VideoExportEngine.
 */
object RichTextCanvasRenderer {

    data class RenderedOverlayBounds(
        val clipId: String,
        val rect: RectF,
        val centerX: Float,
        val centerY: Float,
        val rotationDeg: Float
    )

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.argb(110, 255, 255, 255)
        pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }
    private val snapPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
        color = Color.rgb(0, 210, 255)
    }
    private val selectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = Color.rgb(108, 92, 231)
    }
    private val handleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }

    /**
     * Renders stylized video backdrop, aspect ratio framing, safe zones, Rich Text layers,
     * and Cactus Whistle word-level kinetic captions for [playheadMs].
     */
    fun renderSequenceFrame(
        canvas: Canvas,
        canvasWidth: Float,
        canvasHeight: Float,
        playheadMs: Long,
        aspectRatio: AspectRatioPreset,
        scalingMode: CanvasScalingMode,
        activeVideoClips: List<TimelineClip>,
        activeOverlayClips: List<TimelineClip>,
        selectedClipId: String?,
        showSafeZones: Boolean,
        showSnapGuidesX: Boolean = false,
        showSnapGuidesY: Boolean = false,
        drawSelectionHandles: Boolean = true
    ): List<RenderedOverlayBounds> {
        val boundsList = ArrayList<RenderedOverlayBounds>()

        // 1. Base studio canvas background
        bgPaint.shader = null
        bgPaint.style = Paint.Style.FILL
        bgPaint.color = Color.rgb(9, 11, 16)
        canvas.drawRect(0f, 0f, canvasWidth, canvasHeight, bgPaint)

        // 2. Render simulated or composited Video Track layer with aspect ratio framing
        val primaryVideo = activeVideoClips.lastOrNull()
        if (primaryVideo != null) {
            drawVideoPreviewBackdrop(
                canvas = canvas,
                w = canvasWidth,
                h = canvasHeight,
                clip = primaryVideo,
                playheadMs = playheadMs,
                aspectRatio = aspectRatio,
                scalingMode = primaryVideo.transform.scalingOverride ?: scalingMode
            )
        }

        // 3. Draw Safe-Zone & 9:16 Social UI Exclusion Overlays if enabled in Monitor
        if (showSafeZones && drawSelectionHandles) {
            drawSafeZoneOverlays(canvas, canvasWidth, canvasHeight, aspectRatio)
        }

        // 4. Draw Magnetic Center Snap Guides when dragging text/captions
        if (drawSelectionHandles) {
            if (showSnapGuidesX) {
                canvas.drawLine(canvasWidth / 2f, 0f, canvasWidth / 2f, canvasHeight, snapPaint)
            }
            if (showSnapGuidesY) {
                canvas.drawLine(0f, canvasHeight / 2f, canvasWidth, canvasHeight / 2f, snapPaint)
            }
        }

        // 5. Render Text (T1) and Whistle Caption (C1) clips active at playheadMs
        for (clip in activeOverlayClips) {
            val localTimeMs = (playheadMs - clip.timelineStartMs).coerceAtLeast(0L)
            val bounds = when {
                clip.captionData != null -> renderKineticCaptionClip(
                    canvas = canvas,
                    canvasWidth = canvasWidth,
                    canvasHeight = canvasHeight,
                    clip = clip,
                    caption = clip.captionData,
                    playheadMs = playheadMs
                )
                clip.textData != null -> renderRichTextClip(
                    canvas = canvas,
                    canvasWidth = canvasWidth,
                    canvasHeight = canvasHeight,
                    clip = clip,
                    spec = clip.textData,
                    localTimeMs = localTimeMs
                )
                else -> null
            }

            if (bounds != null) {
                boundsList.add(bounds)
                if (drawSelectionHandles && clip.id == selectedClipId) {
                    drawInteractiveGizmo(canvas, bounds)
                }
            }
        }

        return boundsList
    }

    private fun drawVideoPreviewBackdrop(
        canvas: Canvas,
        w: Float,
        h: Float,
        clip: TimelineClip,
        playheadMs: Long,
        aspectRatio: AspectRatioPreset,
        scalingMode: CanvasScalingMode
    ) {
        val grade = clip.colorGrade
        val progress = ((playheadMs - clip.timelineStartMs).toFloat() / clip.durationMs.coerceAtLeast(1L)).coerceIn(0f, 1f)

        // Compute source media frame rect inside target aspect ratio canvas
        val sourceRatio = 16f / 9f
        val targetRatio = aspectRatio.aspectRatioFloat

        // If BLUR_BACKDROP mode is active on vertical/square canvas, draw soft ambient backdrop first
        if (scalingMode == CanvasScalingMode.BLUR_BACKDROP && targetRatio < sourceRatio) {
            val blurGrad = LinearGradient(
                0f, 0f, w, h,
                intArrayOf(
                     Color.rgb(24, 30, 52),
                    Color.rgb(42, 28, 68),
                    Color.rgb(16, 38, 54)
                ),
                null,
                Shader.TileMode.CLAMP
            )
            bgPaint.shader = blurGrad
            canvas.drawRect(0f, 0f, w, h, bgPaint)
            bgPaint.shader = null
        }

        val frameRect = when (scalingMode) {
            CanvasScalingMode.FILL_CROP, CanvasScalingMode.STRETCH -> RectF(0f, 0f, w, h)
            CanvasScalingMode.FIT_LETTERBOX, CanvasScalingMode.BLUR_BACKDROP -> {
                if (targetRatio < sourceRatio) {
                    val fitH = w / sourceRatio
                    val top = (h - fitH) / 2f
                    RectF(0f, top, w, top + fitH)
                } else {
                    val fitW = h * sourceRatio
                    val left = (w - fitW) / 2f
                    RectF(left, 0f, left + fitW, h)
                }
            }
        }

        canvas.save()
        val cx = frameRect.centerX() + clip.transform.positionX
        val cy = frameRect.centerY() + clip.transform.positionY
        canvas.translate(cx, cy)
        canvas.scale(
            clip.transform.scale * (if (clip.transform.flipHorizontal) -1f else 1f),
            clip.transform.scale * (if (clip.transform.flipVertical) -1f else 1f)
        )
        canvas.rotate(clip.transform.rotationDeg)
        canvas.translate(-frameRect.centerX(), -frameRect.centerY())

        // Render rich color-graded procedural studio scene when no external surface is attached
        val expBoost = (grade.exposure * 28f).toInt()
        val tempShift = (grade.temperature * 0.4f).toInt()
        val c1 = Color.rgb(
            (28 + expBoost + tempShift).coerceIn(0, 255),
            (38 + expBoost).coerceIn(0, 255),
            (68 + expBoost - tempShift).coerceIn(0, 255)
        )
        val c2 = Color.rgb(
            (54 + expBoost + tempShift).coerceIn(0, 255),
            (32 + expBoost).coerceIn(0, 255),
            (92 + expBoost - tempShift).coerceIn(0, 255)
        )
        val c3 = Color.rgb(
            (18 + expBoost).coerceIn(0, 255),
            (64 + expBoost).coerceIn(0, 255),
            (88 + expBoost).coerceIn(0, 255)
        )

        val sceneGrad = LinearGradient(
            frameRect.left + progress * 120f,
            frameRect.top,
            frameRect.right,
            frameRect.bottom,
            intArrayOf(c1, c2, c3),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        bgPaint.shader = sceneGrad
        bgPaint.alpha = (clip.opacity * 255).toInt().coerceIn(0, 255)
        canvas.drawRoundRect(frameRect, 4f, 4f, bgPaint)
        bgPaint.shader = null

        // Subtle horizon grid & animated light pulse for visual motion feedback during scrubbing
        val pulseX = frameRect.left + frameRect.width() * (0.2f + 0.6f * progress)
        val pulseY = frameRect.centerY() + sin(progress * Math.PI * 2.0).toFloat() * (frameRect.height() * 0.12f)
        bgPaint.color = Color.argb(42, 0, 210, 255)
        canvas.drawCircle(pulseX, pulseY, frameRect.width() * 0.16f, bgPaint)

        canvas.restore()
    }

    private fun drawSafeZoneOverlays(
        canvas: Canvas,
        w: Float,
        h: Float,
        aspectRatio: AspectRatioPreset
    ) {
        // Action Safe (93%) & Title Safe (88%)
        val actionMarginX = w * 0.035f
        val actionMarginY = h * 0.035f
        guidePaint.color = Color.argb(75, 255, 255, 255)
        canvas.drawRect(actionMarginX, actionMarginY, w - actionMarginX, h - actionMarginY, guidePaint)

        val titleMarginX = w * 0.06f
        val titleMarginY = h * 0.06f
        guidePaint.color = Color.argb(95, 0, 210, 255)
        canvas.drawRect(titleMarginX, titleMarginY, w - titleMarginX, h - titleMarginY, guidePaint)

        // Social UI Safe Zone for 9:16 Reels / Shorts / TikTok (Right icon rail & bottom caption area)
        if (aspectRatio.showSocialUiSafeZones) {
            val socialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.argb(38, 255, 82, 82)
            }
            // Right-side social action buttons exclusion zone
            canvas.drawRoundRect(
                RectF(w * 0.82f, h * 0.42f, w * 0.96f, h * 0.84f),
                12f, 12f, socialPaint
            )
            // Bottom description & audio ticker exclusion zone
            canvas.drawRoundRect(
                RectF(w * 0.04f, h * 0.86f, w * 0.80f, h * 0.96f),
                12f, 12f, socialPaint
            )
        }
    }

    private fun renderRichTextClip(
        canvas: Canvas,
        canvasWidth: Float,
        canvasHeight: Float,
        clip: TimelineClip,
        spec: RichTextSpec,
        localTimeMs: Long
    ): RenderedOverlayBounds {
        val scaleFactor = min(canvasWidth, canvasHeight) / 720f
        val effectiveFontSizePx = (spec.fontSizeSp * scaleFactor).coerceAtLeast(14f)

        val displayString = computeAnimatedSubstring(spec.formattedText(), localTimeMs, spec.animationPreset, spec.animationInDurationMs)
        val lines = displayString.split("\n").ifEmpty { listOf(displayString) }

        val textPaint = createConfiguredTextPaint(spec, effectiveFontSizePx)
        val fontMetrics = textPaint.fontMetrics
        val singleLineHeight = (fontMetrics.descent - fontMetrics.ascent) * spec.lineHeightMultiplier
        val maxLineWidth = lines.maxOfOrNull { textPaint.measureText(it) } ?: 120f
        val totalTextHeight = singleLineHeight * lines.size

        // Entrance animation offset
        val entranceProgress = if (spec.animationInDurationMs > 0) {
            (localTimeMs.toFloat() / spec.animationInDurationMs.toFloat()).coerceIn(0f, 1f)
        } else 1f

        val animOffsetY = when (spec.animationPreset) {
            TextAnimationPreset.FADE_UP_WORDS -> (1f - entranceProgress) * 28f * scaleFactor
            else -> 0f
        }
        val animScale = when (spec.animationPreset) {
            TextAnimationPreset.SLIDE_ELASTIC -> 0.85f + 0.15f * entranceProgress
            else -> 1.0f
        }
        val effectiveAlpha = (spec.opacity * clip.opacity * entranceProgress * 255f).toInt().coerceIn(0, 255)

        val centerX = spec.normalizedX * canvasWidth
        val centerY = spec.normalizedY * canvasHeight + animOffsetY

        val padH = spec.backgroundPaddingHPx * scaleFactor
        val padV = spec.backgroundPaddingVPx * scaleFactor
        val boxRect = RectF(
            centerX - maxLineWidth / 2f - padH,
            centerY - totalTextHeight / 2f - padV,
            centerX + maxLineWidth / 2f + padH,
            centerY + totalTextHeight / 2f + padV
        )

        canvas.save()
        canvas.translate(centerX, centerY)
        canvas.scale(spec.scale * animScale, spec.scale * animScale)
        canvas.rotate(spec.rotationDeg)
        canvas.translate(-centerX, -centerY)

        // 1. Background Box / Pill
        if (spec.backgroundEnabled) {
            val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = spec.backgroundColorArgb.toInt()
                alpha = ((Color.alpha(spec.backgroundColorArgb.toInt()) * effectiveAlpha) / 255).coerceIn(0, 255)
            }
            val radius = spec.backgroundCornerRadiusPx * scaleFactor
            canvas.drawRoundRect(boxRect, radius, radius, pillPaint)
        }

        // 2. Render each line with Outer Stroke -> Inner Stroke -> Drop Shadow -> Fill/Gradient
        lines.forEachIndexed { idx, line ->
            val lineY = (centerY - totalTextHeight / 2f) + idx * singleLineHeight - fontMetrics.ascent
            val lineX = when (spec.textAlign) {
                TextAlignMode.LEFT -> boxRect.left + padH
                TextAlignMode.CENTER -> centerX
                TextAlignMode.RIGHT -> boxRect.right - padH
            }

            drawMultiLayerTextLine(
                canvas = canvas,
                text = line,
                x = lineX,
                y = lineY,
                spec = spec,
                basePaint = textPaint,
                scaleFactor = scaleFactor,
                effectiveAlpha = effectiveAlpha
            )
        }

        canvas.restore()

        return RenderedOverlayBounds(
            clipId = clip.id,
            rect = boxRect,
            centerX = centerX,
            centerY = centerY,
            rotationDeg = spec.rotationDeg
        )
    }

    /**
     * Renders word-by-word synchronized captions using Cactus Whistle word timestamps.
     */
    private fun renderKineticCaptionClip(
        canvas: Canvas,
        canvasWidth: Float,
        canvasHeight: Float,
        clip: TimelineClip,
        caption: CaptionSegmentSpec,
        playheadMs: Long
    ): RenderedOverlayBounds {
        val spec = caption.richStyle
        val scaleFactor = min(canvasWidth, canvasHeight) / 720f
        val effectiveFontSizePx = (spec.fontSizeSp * scaleFactor).coerceAtLeast(16f)
        val basePaint = createConfiguredTextPaint(spec, effectiveFontSizePx)
        basePaint.textAlign = Paint.Align.LEFT

        val words = if (caption.words.isNotEmpty()) {
            caption.words
        } else {
            emptyList()
        }

        val centerX = spec.normalizedX * canvasWidth
        val centerY = spec.normalizedY * canvasHeight

        if (words.isEmpty()) {
            return renderRichTextClip(
                canvas, canvasWidth, canvasHeight, clip,
                spec.copy(text = caption.rawText),
                playheadMs - clip.timelineStartMs
            )
        }

        // Group words into lines of up to caption.maxWordsPerLine
        val maxPerLine = caption.maxWordsPerLine.coerceIn(2, 8)
        val wordLines = words.chunked(maxPerLine)
        val fontMetrics = basePaint.fontMetrics
        val lineHeight = (fontMetrics.descent - fontMetrics.ascent) * spec.lineHeightMultiplier
        val spaceWidth = basePaint.measureText(" ") * 1.12f

        val lineWidths = wordLines.map { lineWords ->
            lineWords.sumOf { w ->
                val formatted = formatWordCase(w.word, spec.caseMode)
                basePaint.measureText(formatted).toDouble()
            }.toFloat() + (lineWords.size - 1).coerceAtLeast(0) * spaceWidth
        }

        val maxWidth = (lineWidths.maxOrNull() ?: 160f).coerceAtLeast(80f)
        val totalHeight = lineHeight * wordLines.size
        val padH = spec.backgroundPaddingHPx * scaleFactor
        val padV = spec.backgroundPaddingVPx * scaleFactor

        val boxRect = RectF(
            centerX - maxWidth / 2f - padH,
            centerY - totalHeight / 2f - padV,
            centerX + maxWidth / 2f + padH,
            centerY + totalHeight / 2f + padV
        )

        canvas.save()
        canvas.translate(centerX, centerY)
        canvas.scale(spec.scale, spec.scale)
        canvas.rotate(spec.rotationDeg)
        canvas.translate(-centerX, -centerY)

        // Optional full-caption backdrop box
        if (spec.backgroundEnabled) {
            val bgBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = spec.backgroundColorArgb.toInt()
            }
            val r = spec.backgroundCornerRadiusPx * scaleFactor
            canvas.drawRoundRect(boxRect, r, r, bgBoxPaint)
        }

        // Render each word with active-word highlight / pill / scale pop when playheadMs is inside [startMs, endMs]
        wordLines.forEachIndexed { lineIdx, lineWords ->
            val lineW = lineWidths[lineIdx]
            var cursorX = centerX - lineW / 2f
            val baselineY = (centerY - totalHeight / 2f) + lineIdx * lineHeight - fontMetrics.ascent

            for (wordItem in lineWords) {
                val formattedWord = formatWordCase(wordItem.word, spec.caseMode)
                val wordW = basePaint.measureText(formattedWord)
                val isSpokenNow = playheadMs in wordItem.startMs..wordItem.endMs
                val wasAlreadySpoken = playheadMs > wordItem.endMs

                canvas.save()
                val wordCenterX = cursorX + wordW / 2f
                val wordCenterY = baselineY + (fontMetrics.ascent + fontMetrics.descent) / 2f

                if (isSpokenNow && caption.activeWordScalePop > 1.0f) {
                    canvas.translate(wordCenterX, wordCenterY)
                    canvas.scale(caption.activeWordScalePop, caption.activeWordScalePop)
                    canvas.translate(-wordCenterX, -wordCenterY)
                }

                // Active word background pill sweep
                if (isSpokenNow && caption.showActiveWordPill) {
                    val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.FILL
                        color = caption.activeWordPillColorArgb.toInt()
                    }
                    val pillPadX = 10f * scaleFactor
                    val pillPadY = 5f * scaleFactor
                    val wordRect = RectF(
                        cursorX - pillPadX,
                        baselineY + fontMetrics.ascent - pillPadY,
                        cursorX + wordW + pillPadX,
                        baselineY + fontMetrics.descent + pillPadY
                    )
                    canvas.drawRoundRect(wordRect, 14f * scaleFactor, 14f * scaleFactor, pillPaint)
                }

                // Stroke layer
                if (spec.strokeEnabled && spec.strokeWidthPx > 0f) {
                    val strokePaint = TextPaint(basePaint).apply {
                        style = Paint.Style.STROKE
                        strokeWidth = spec.strokeWidthPx * scaleFactor
                        strokeJoin = Paint.Join.ROUND
                        color = spec.strokeColorArgb.toInt()
                    }
                    canvas.drawText(formattedWord, cursorX, baselineY, strokePaint)
                }

                // Fill layer (Active word gets activeWordHighlightColorArgb)
                val fillPaint = TextPaint(basePaint).apply {
                    style = Paint.Style.FILL
                    color = when {
                        isSpokenNow -> caption.activeWordHighlightColorArgb.toInt()
                        wasAlreadySpoken -> spec.primaryColorArgb.toInt()
                        else -> Color.argb(
                            215,
                            Color.red(spec.primaryColorArgb.toInt()),
                            Color.green(spec.primaryColorArgb.toInt()),
                            Color.blue(spec.primaryColorArgb.toInt())
                        )
                    }
                    if (spec.shadowEnabled) {
                        setShadowLayer(
                            (spec.shadowBlurPx * scaleFactor).coerceAtLeast(1f),
                            spec.shadowOffsetX * scaleFactor,
                            spec.shadowOffsetY * scaleFactor,
                            spec.shadowColorArgb.toInt()
                        )
                    }
                }
                canvas.drawText(formattedWord, cursorX, baselineY, fillPaint)
                canvas.restore()

                cursorX += wordW + spaceWidth
            }
        }

        canvas.restore()

        return RenderedOverlayBounds(
            clipId = clip.id,
            rect = boxRect,
            centerX = centerX,
            centerY = centerY,
            rotationDeg = spec.rotationDeg
        )
    }

    private fun drawMultiLayerTextLine(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        spec: RichTextSpec,
        basePaint: TextPaint,
        scaleFactor: Float,
        effectiveAlpha: Int
    ) {
        // 1. Outer Stroke
        if (spec.outerStrokeEnabled && spec.outerStrokeWidthPx > 0f) {
            val outerPaint = TextPaint(basePaint).apply {
                style = Paint.Style.STROKE
                strokeWidth = (spec.outerStrokeWidthPx + spec.strokeWidthPx) * scaleFactor
                strokeJoin = Paint.Join.ROUND
                color = spec.outerStrokeColorArgb.toInt()
                alpha = effectiveAlpha
            }
            canvas.drawText(text, x, y, outerPaint)
        }

        // 2. Primary Stroke
        if (spec.strokeEnabled && spec.strokeWidthPx > 0f) {
            val strokePaint = TextPaint(basePaint).apply {
                style = Paint.Style.STROKE
                strokeWidth = spec.strokeWidthPx * scaleFactor
                strokeJoin = Paint.Join.ROUND
                color = spec.strokeColorArgb.toInt()
                alpha = effectiveAlpha
            }
            canvas.drawText(text, x, y, strokePaint)
        }

        // 3. Fill + Gradient + Drop Shadow
        val fillPaint = TextPaint(basePaint).apply {
            style = Paint.Style.FILL
            color = spec.primaryColorArgb.toInt()
            alpha = effectiveAlpha
            if (spec.shadowEnabled && spec.shadowBlurPx > 0f) {
                setShadowLayer(
                    spec.shadowBlurPx * scaleFactor,
                    spec.shadowOffsetX * scaleFactor,
                    spec.shadowOffsetY * scaleFactor,
                    spec.shadowColorArgb.toInt()
                )
            }
            if (spec.fillType == TextFillType.LINEAR_GRADIENT) {
                val rad = Math.toRadians(spec.gradientAngleDeg.toDouble())
                val dx = cos(rad).toFloat() * 120f * scaleFactor
                val dy = sin(rad).toFloat() * 120f * scaleFactor
                shader = LinearGradient(
                    x - dx, y - dy, x + dx, y + dy,
                    spec.primaryColorArgb.toInt(),
                    spec.secondaryColorArgb.toInt(),
                    Shader.TileMode.CLAMP
                )
            }
        }
        canvas.drawText(text, x, y, fillPaint)
    }

    private fun drawInteractiveGizmo(canvas: Canvas, bounds: RenderedOverlayBounds) {
        canvas.save()
        canvas.translate(bounds.centerX, bounds.centerY)
        canvas.rotate(bounds.rotationDeg)
        canvas.translate(-bounds.centerX, -bounds.centerY)

        val r = bounds.rect
        canvas.drawRoundRect(r, 8f, 8f, selectionPaint)

        // 4 Corner scale handles + Top rotation stem
        val handleRadius = 7.5f
        val corners = listOf(
            r.left to r.top,
            r.right to r.top,
            r.left to r.bottom,
            r.right to r.bottom
        )
        for ((cx, cy) in corners) {
            canvas.drawCircle(cx, cy, handleRadius, handleFillPaint)
            canvas.drawCircle(cx, cy, handleRadius, selectionPaint)
        }

        // Top rotation handle
        val rotY = r.top - 26f
        canvas.drawLine(r.centerX(), r.top, r.centerX(), rotY, selectionPaint)
        canvas.drawCircle(r.centerX(), rotY, handleRadius + 1.5f, handleFillPaint)
        canvas.drawCircle(r.centerX(), rotY, handleRadius + 1.5f, selectionPaint)

        canvas.restore()
    }

    private fun createConfiguredTextPaint(spec: RichTextSpec, fontSizePx: Float): TextPaint {
        return TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            textSize = fontSizePx
            letterSpacing = spec.letterSpacingEm
            isUnderlineText = spec.isUnderline
            isStrikeThruText = spec.isStrikethrough
            val styleBits = when {
                spec.fontWeight >= 700 && spec.isItalic -> Typeface.BOLD_ITALIC
                spec.fontWeight >= 700 -> Typeface.BOLD
                spec.isItalic -> Typeface.ITALIC
                else -> Typeface.NORMAL
            }
            typeface = Typeface.create(spec.fontFamily.systemFamilyName, styleBits)
            textAlign = when (spec.textAlign) {
                TextAlignMode.LEFT -> Paint.Align.LEFT
                TextAlignMode.CENTER -> Paint.Align.CENTER
                TextAlignMode.RIGHT -> Paint.Align.RIGHT
            }
        }
    }

    private fun computeAnimatedSubstring(
        fullText: String,
        localTimeMs: Long,
        preset: TextAnimationPreset,
        animDurationMs: Long
    ): String {
        if (preset != TextAnimationPreset.TYPEWRITER || animDurationMs <= 0L) {
            return fullText
        }
        val fraction = (localTimeMs.toFloat() / (animDurationMs * 2.5f)).coerceIn(0.05f, 1.0f)
        val charCount = (fullText.length * fraction).toInt().coerceIn(1, fullText.length)
        return fullText.substring(0, charCount)
    }

    private fun formatWordCase(word: String, mode: com.pulsecut.pro.model.TextCaseMode): String {
        return when (mode) {
            com.pulsecut.pro.model.TextCaseMode.ORIGINAL -> word
            com.pulsecut.pro.model.TextCaseMode.UPPERCASE -> word.uppercase()
            com.pulsecut.pro.model.TextCaseMode.LOWERCASE -> word.lowercase()
            com.pulsecut.pro.model.TextCaseMode.TITLE_CASE ->
                word.lowercase().replaceFirstChar { it.uppercase() }
        }
    }
}
