package com.pulsecut.pro.shortcuts

import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isAltPressed
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isMetaPressed
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import com.pulsecut.pro.model.EditTool

data class ShortcutEntry(
    val category: String,
    val keyCombo: String,
    val actionName: String,
    val description: String
)

sealed class PremiereCommand {
    data object TogglePlayPause : PremiereCommand()
    data object ShuttleReverseJ : PremiereCommand()
    data object ShuttleStopK : PremiereCommand()
    data object ShuttleForwardL : PremiereCommand()
    data class StepFrames(val deltaFrames: Int) : PremiereCommand()
    data object JumpToStart : PremiereCommand()
    data object JumpToEnd : PremiereCommand()
    data object JumpToPreviousEdit : PremiereCommand()
    data object JumpToNextEdit : PremiereCommand()

    data class SelectTool(val tool: EditTool) : PremiereCommand()
    data class SplitAtPlayhead(val allTracks: Boolean) : PremiereCommand()
    data object RippleTrimPreviousToPlayheadQ : PremiereCommand()
    data object RippleTrimNextToPlayheadW : PremiereCommand()
    data object MarkInPointI : PremiereCommand()
    data object MarkOutPointO : PremiereCommand()
    data object MarkClipX : PremiereCommand()
    data object ClearInOutPoints : PremiereCommand()
    data object InsertFromSourceComma : PremiereCommand()
    data object OverwriteFromSourcePeriod : PremiereCommand()
    data object AddMarkerM : PremiereCommand()
    data object LiftDelete : PremiereCommand()
    data object RippleDelete : PremiereCommand()
    data object Undo : PremiereCommand()
    data object Redo : PremiereCommand()
    data object DuplicateClip : PremiereCommand()
    data object ToggleSnapS : PremiereCommand()
    data object ZoomInTimeline : PremiereCommand()
    data object ZoomOutTimeline : PremiereCommand()
    data object ZoomFitTimeline : PremiereCommand()
    data object CycleAspectRatio : PremiereCommand()
    data object TranscribeWithWhistle : PremiereCommand()
    data object ToggleShortcutsModal : PremiereCommand()
}

/**
 * Hardware Keyboard Interceptor implementing Adobe Premiere Pro's default NLE keymap
 * on Android tablets (USB-C, Pogo-pin Book Cover, or Bluetooth keyboards).
 */
class PremiereShortcutManager {

    private var isKHeldDown = false

    fun onHardwareKeyEvent(
        event: KeyEvent,
        isTextInputFocused: Boolean
    ): PremiereCommand? {
        if (event.key == Key.K) {
            isKHeldDown = (event.type == KeyEventType.KeyDown)
        }

        if (event.type != KeyEventType.KeyDown) {
            return null
        }

        val ctrl = event.isCtrlPressed || event.isMetaPressed
        val shift = event.isShiftPressed
        val alt = event.isAltPressed

        // Allow Ctrl/Cmd shortcuts even when a text field has focus
        if (isTextInputFocused && !ctrl) {
            return null
        }

        // Ctrl / Cmd combinations
        if (ctrl) {
            return when (event.key) {
                Key.K -> PremiereCommand.SplitAtPlayhead(allTracks = shift)
                Key.Z -> if (shift) PremiereCommand.Redo else PremiereCommand.Undo
                Key.Y -> PremiereCommand.Redo
                Key.D -> PremiereCommand.DuplicateClip
                Key.Slash -> PremiereCommand.ToggleShortcutsModal
                else -> null
            }
        }

        // Single-key & Shift-modified Premiere Pro shortcuts
        return when (event.key) {
            Key.Spacebar -> PremiereCommand.TogglePlayPause
            Key.J -> if (isKHeldDown) PremiereCommand.StepFrames(-1) else PremiereCommand.ShuttleReverseJ
            Key.K -> PremiereCommand.ShuttleStopK
            Key.L -> if (isKHeldDown) PremiereCommand.StepFrames(1) else PremiereCommand.ShuttleForwardL

            Key.DirectionLeft -> PremiereCommand.StepFrames(if (shift) -5 else -1)
            Key.DirectionRight -> PremiereCommand.StepFrames(if (shift) 5 else 1)
            Key.DirectionUp -> PremiereCommand.JumpToPreviousEdit
            Key.DirectionDown -> PremiereCommand.JumpToNextEdit
            Key.MoveHome -> PremiereCommand.JumpToStart
            Key.MoveEnd -> PremiereCommand.JumpToEnd

            // Premiere Pro Tool Selection Keys
            Key.V -> PremiereCommand.SelectTool(EditTool.SELECTION_V)
            Key.A -> PremiereCommand.SelectTool(EditTool.TRACK_SELECT_A)
            Key.B -> PremiereCommand.SelectTool(EditTool.RIPPLE_EDIT_B)
            Key.N -> PremiereCommand.SelectTool(EditTool.ROLLING_EDIT_N)
            Key.R -> PremiereCommand.SelectTool(EditTool.RATE_STRETCH_R)
            Key.C -> PremiereCommand.SelectTool(EditTool.RAZOR_C)
            Key.Y -> PremiereCommand.SelectTool(EditTool.SLIP_Y)
            Key.U -> PremiereCommand.SelectTool(EditTool.SLIDE_U)
            Key.T -> PremiereCommand.SelectTool(EditTool.TYPE_T)
            Key.H -> PremiereCommand.SelectTool(EditTool.HAND_H)
            Key.Z -> PremiereCommand.SelectTool(EditTool.ZOOM_Z)

            // Fast Trim & 3-Point Editing
            Key.Q -> PremiereCommand.RippleTrimPreviousToPlayheadQ
            Key.W -> PremiereCommand.RippleTrimNextToPlayheadW
            Key.I -> if (alt) PremiereCommand.ClearInOutPoints else PremiereCommand.MarkInPointI
            Key.O -> if (alt) PremiereCommand.ClearInOutPoints else PremiereCommand.MarkOutPointO
            Key.X -> PremiereCommand.MarkClipX
            Key.Comma -> PremiereCommand.InsertFromSourceComma
            Key.Period -> PremiereCommand.OverwriteFromSourcePeriod
            Key.M -> PremiereCommand.AddMarkerM
            Key.S -> PremiereCommand.ToggleSnapS

            // Delete & Ripple Delete
            Key.ForwardDel, Key.Backspace -> {
                if (shift) PremiereCommand.RippleDelete else PremiereCommand.LiftDelete
            }

            // Zoom & Aspect Ratio & Whistle Quick Triggers
            Key.Equals, Key.NumPadAdd -> PremiereCommand.ZoomInTimeline
            Key.Minus, Key.NumPadSubtract -> PremiereCommand.ZoomOutTimeline
            Key.Backslash -> PremiereCommand.ZoomFitTimeline
            Key.F2 -> PremiereCommand.CycleAspectRatio
            Key.F5 -> PremiereCommand.TranscribeWithWhistle
            Key.Slash -> if (shift) PremiereCommand.ToggleShortcutsModal else null
            else -> null
        }
    }

    companion object {
        val ALL_PREMIERE_SHORTCUTS: List<ShortcutEntry> = listOf(
            ShortcutEntry("Transport & Shuttle", "Space", "Play / Pause", "Starts or pauses sequence playback"),
            ShortcutEntry("Transport & Shuttle", "J / K / L", "Shuttle Reverse / Stop / Forward", "Multi-press J or L for -4x, -2x, -1x, 1x, 2x, 4x shuttle speed"),
            ShortcutEntry("Transport & Shuttle", "K + J / K + L", "Step 1 Frame Back / Forward", "Precision single-frame stepping while holding K"),
            ShortcutEntry("Transport & Shuttle", "← / → (Shift: ±5f)", "Step 1 or 5 Frames", "Nudges playhead by 1 frame (or 5 frames with Shift)"),
            ShortcutEntry("Transport & Shuttle", "↑ / ↓", "Previous / Next Edit Point", "Snaps playhead to nearest clip cut point"),
            ShortcutEntry("Tools (Premiere Pro)", "V", "Selection Tool", "Select, move, and trim clips"),
            ShortcutEntry("Tools (Premiere Pro)", "C", "Razor (Blade) Tool", "Click any clip or press C to slice"),
            ShortcutEntry("Tools (Premiere Pro)", "B / N", "Ripple Edit / Rolling Edit", "Trim with downstream ripple (B) or shared cut roll (N)"),
            ShortcutEntry("Tools (Premiere Pro)", "Y / U", "Slip Tool / Slide Tool", "Shift clip source In/Out (Y) or slide between neighbors (U)"),
            ShortcutEntry("Tools (Premiere Pro)", "A", "Track Select Forward", "Selects all clips at or after the playhead"),
            ShortcutEntry("Tools (Premiere Pro)", "T", "Type Tool (Rich Text)", "Adds a new stylized Rich Text layer on the Program Monitor"),
            ShortcutEntry("Fast Editing", "Q / W", "Ripple Trim Prev / Next to Playhead", "Top/tail trims clip to playhead and closes timeline gap"),
            ShortcutEntry("Fast Editing", "Ctrl + K (Shift: All)", "Add Edit (Split)", "Splits selected clip or all unlocked tracks at playhead"),
            ShortcutEntry("Fast Editing", "I / O / X", "Mark In / Out / Mark Clip", "Sets sequence In and Out points"),
            ShortcutEntry("Fast Editing", ", (Comma) / . (Period)", "Insert / Overwrite", "Splices or overwrites active Source Monitor clip at playhead"),
            ShortcutEntry("Fast Editing", "Shift + Delete", "Ripple Delete", "Deletes selected clip and ripples downstream clips left"),
            ShortcutEntry("Timeline & AI", "= / - / \\", "Zoom In / Out / Fit", "Scales timeline time-ruler or fits entire sequence"),
            ShortcutEntry("Timeline & AI", "S / M", "Toggle Snap / Add Marker", "Toggles magnetic snapping or drops a sequence marker"),
            ShortcutEntry("Timeline & AI", "F2 / F5", "Cycle Aspect Ratio / Whistle STT", "Switches 16:9, 9:16, 1:1, 4:5 or runs Cactus Whistle captions")
        )
    }
}
