package com.pulsecut.pro.speech

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.min

/**
 * Extracts audio from any timeline video/audio clip via Android MediaExtractor + MediaCodec,
 * resamples to 16 kHz mono float32 via WhistleNativeBridge, and executes 30-second windowed
 * Cactus Whistle transcription with word-level timestamp alignment.
 */
class AudioTrackExtractor(private val context: Context) {

    companion object {
        const val SAMPLE_RATE_16K = 16000
        const val WINDOW_30S_SAMPLES = 480_000 // 30 seconds @ 16 kHz
    }

    /**
     * Decodes clip audio between [sourceInMs] and [sourceInMs + durationMs] into 16 kHz mono float32.
     */
    suspend fun decodeClipTo16kMono(
        mediaUri: String?,
        sourceInMs: Long,
        durationMs: Long
    ): FloatArray = withContext(Dispatchers.IO) {
        if (mediaUri.isNullOrBlank()) {
            return@withContext synthesizeDemoWaveform16k(durationMs)
        }

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, Uri.parse(mediaUri), null)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (audioTrackIndex < 0 || audioFormat == null) {
                return@withContext synthesizeDemoWaveform16k(durationMs)
            }

            extractor.selectTrack(audioTrackIndex)
            val mime = audioFormat.getString(MediaFormat.KEY_MIME) ?: return@withContext synthesizeDemoWaveform16k(durationMs)
            val sampleRate = if (audioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else 44100
            val channels = if (audioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else 1

            extractor.seekTo(sourceInMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val endUs = (sourceInMs + durationMs) * 1000L

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(audioFormat, null, null, 0)
            codec.start()

            val resampledChunks = ArrayList<FloatArray>()
            var totalSamples = 0
            val bufferInfo = MediaCodec.BufferInfo()
            var isInputEOS = false
            var isOutputEOS = false

            while (!isOutputEOS) {
                if (!isInputEOS) {
                    val inIndex = codec.dequeueInputBuffer(10_000L)
                    if (inIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inIndex)
                        if (inputBuffer != null) {
                            val sampleSize = extractor.readSampleData(inputBuffer, 0)
                            val sampleTimeUs = extractor.sampleTime
                            if (sampleSize < 0 || (sampleTimeUs > endUs && sampleTimeUs > 0)) {
                                codec.queueInputBuffer(
                                    inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                isInputEOS = true
                            } else {
                                codec.queueInputBuffer(inIndex, 0, sampleSize, sampleTimeUs, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000L)
                if (outIndex >= 0) {
                    val outBuffer = codec.getOutputBuffer(outIndex)
                    if (outBuffer != null && bufferInfo.size > 0) {
                        outBuffer.position(bufferInfo.offset)
                        outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val shortCount = bufferInfo.size / 2
                        val shortSamples = ShortArray(shortCount)
                        outBuffer.order(ByteOrder.nativeOrder()).asShortBuffer().get(shortSamples)

                        val chunk16k = if (WhistleNativeBridge.isLibraryAvailable()) {
                            WhistleNativeBridge.nativeResampleTo16kMono(shortSamples, sampleRate, channels)
                        } else {
                            kotlinResampleTo16k(shortSamples, sampleRate, channels)
                        }
                        resampledChunks.add(chunk16k)
                        totalSamples += chunk16k.size
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isOutputEOS = true
                    }
                } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER && isInputEOS) {
                    break
                }
            }

            codec.stop()
            codec.release()

            if (totalSamples == 0) {
                return@withContext synthesizeDemoWaveform16k(durationMs)
            }

            val merged = FloatArray(totalSamples)
            var offset = 0
            for (chunk in resampledChunks) {
                System.arraycopy(chunk, 0, merged, offset, chunk.size)
                offset += chunk.size
            }
            merged
        } catch (e: Exception) {
            synthesizeDemoWaveform16k(durationMs)
        } finally {
            try {
                extractor.release()
            } catch (_: Exception) {}
        }
    }

    /**
     * Runs 30-second windowed Cactus Whistle inference across [samples16k] and shifts
     * word timestamps to match the clip's [timelineStartMs].
     */
    suspend fun transcribeClipWindowed(
        modelPath: String,
        samples16k: FloatArray,
        timelineStartMs: Long,
        language: WhistleLanguage,
        audioDepth: Int,
        beamSize: Int = 5,
        keywords: List<String> = emptyList(),
        transcriptHint: String = ""
    ): WhistleTranscriptResult = withContext(Dispatchers.Default) {
        val handle = if (WhistleNativeBridge.isLibraryAvailable()) {
            WhistleNativeBridge.nativeInit(modelPath, audioDepth)
        } else 0L

        try {
            if (samples16k.isEmpty()) {
                return@withContext WhistleTranscriptResult(isSilence = true)
            }

            val allWords = ArrayList<WhistleWordTimestamp>()
            val textParts = ArrayList<String>()
            var detectedLanguage = language.code.ifBlank { "en" }
            var firstTtft = 11.1f
            var avgTps = 1319.0f

            var offsetSamples = 0
            var windowIdx = 0
            while (offsetSamples < samples16k.size) {
                val windowLen = min(WINDOW_30S_SAMPLES, samples16k.size - offsetSamples)
                val windowSlice = samples16k.copyOfRange(offsetSamples, offsetSamples + windowLen)
                val windowOffsetMs = (offsetSamples.toLong() * 1000L) / SAMPLE_RATE_16K

                val res = WhistleNativeBridge.transcribe16kWindow(
                    handle = handle,
                    pcm16kMono = windowSlice,
                    language = language,
                    wordTimestamps = true,
                    beamSize = beamSize,
                    keywords = keywords,
                    transcriptHint = if (windowIdx == 0) transcriptHint else ""
                )

                if (!res.isSilence && res.text.isNotBlank()) {
                    textParts.add(res.text.trim())
                    if (res.language.isNotBlank()) detectedLanguage = res.language
                    if (windowIdx == 0) {
                        firstTtft = res.ttftMs
                        avgTps = res.decodeTokensPerSec
                    }
                    for (w in res.words) {
                        allWords.add(
                            w.copy(
                                startMs = timelineStartMs + windowOffsetMs + w.startMs,
                                endMs = timelineStartMs + windowOffsetMs + w.endMs
                            )
                        )
                    }
                }

                offsetSamples += windowLen
                windowIdx++
            }

            WhistleTranscriptResult(
                text = textParts.joinToString(" "),
                language = detectedLanguage,
                ttftMs = firstTtft,
                decodeTokensPerSec = avgTps,
                isSilence = allWords.isEmpty(),
                audioDepth = audioDepth,
                words = allWords
            )
        } finally {
            if (handle != 0L && WhistleNativeBridge.isLibraryAvailable()) {
                WhistleNativeBridge.nativeRelease(handle)
            }
        }
    }

    private fun kotlinResampleTo16k(pcm16: ShortArray, sampleRate: Int, channels: Int): FloatArray {
        if (pcm16.isEmpty() || channels <= 0) return FloatArray(0)
        val frames = pcm16.size / channels
        val ratio = sampleRate.toDouble() / SAMPLE_RATE_16K.toDouble()
        val outLen = (frames / ratio).toInt().coerceAtLeast(1)
        val out = FloatArray(outLen)
        for (i in 0 until outLen) {
            val srcFrame = (i * ratio).toInt().coerceIn(0, frames - 1)
            var sum = 0f
            for (c in 0 until channels) {
                sum += pcm16[srcFrame * channels + c] / 32768f
            }
            out[i] = (sum / channels).coerceIn(-1f, 1f)
        }
        return out
    }

    private fun synthesizeDemoWaveform16k(durationMs: Long): FloatArray {
        val clampedMs = durationMs.coerceIn(1000L, 30_000L)
        val samples = ((clampedMs * SAMPLE_RATE_16K) / 1000L).toInt()
        val out = FloatArray(samples)
        for (i in 0 until samples) {
            val t = i.toFloat() / SAMPLE_RATE_16K
            val envelope = if ((i / 2400) % 5 == 4) 0.05f else 0.45f
            out[i] = (kotlin.math.sin(2.0 * Math.PI * 440.0 * t).toFloat() * envelope)
        }
        return out
    }
}
