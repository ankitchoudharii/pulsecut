package com.pulsecut.pro.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsecut.pro.model.AspectRatioPreset
import com.pulsecut.pro.model.CanvasScalingMode
import com.pulsecut.pro.model.CaptionStylePreset
import com.pulsecut.pro.model.ClipTransform
import com.pulsecut.pro.model.ColorGradeConfig
import com.pulsecut.pro.model.EditorFontFamily
import com.pulsecut.pro.model.ExportResolutionTier
import com.pulsecut.pro.model.ProjectSequence
import com.pulsecut.pro.model.RichTextSpec
import com.pulsecut.pro.model.TextAlignMode
import com.pulsecut.pro.model.TextAnimationPreset
import com.pulsecut.pro.model.TextCaseMode
import com.pulsecut.pro.model.TextFillType
import com.pulsecut.pro.model.TimelineClip
import com.pulsecut.pro.model.TrackType
import com.pulsecut.pro.speech.WhistleLanguage
import com.pulsecut.pro.speech.WhistleModelStatus
import com.pulsecut.pro.viewmodel.InspectorTab

@Composable
fun InspectorTabsPanel(
    activeTab: InspectorTab,
    onSelectTab: (InspectorTab) -> Unit,
    sequence: ProjectSequence,
    selectedClip: TimelineClip?,
    playheadMs: Long,
    whistleStatus: WhistleModelStatus,
    whistleLanguage: WhistleLanguage,
    whistleKeywords: List<String>,
    selectedCaptionPreset: CaptionStylePreset,
    isTranscribing: Boolean,
    lastWhistleMetrics: String,
    onSelectLanguage: (WhistleLanguage) -> Unit,
    onSetAudioDepth: (Int) -> Unit,
    onAddKeyword: (String) -> Unit,
    onRemoveKeyword: (String) -> Unit,
    onDownloadWhistleWeights: () -> Unit,
    onTranscribeWithWhistle: () -> Unit,
    onApplyCaptionPreset: (CaptionStylePreset) -> Unit,
    onUpdateCaptionText: (String, String) -> Unit,
    onRippleCutWord: (String, Int) -> Unit,
    onSeekToMs: (Long) -> Unit,
    onShowSubtitleExportDialog: () -> Unit,
    onAddNewRichTextClip: () -> Unit,
    onUpdateRichText: ((RichTextSpec) -> RichTextSpec) -> Unit,
    onSelectAspectRatio: (AspectRatioPreset) -> Unit,
    onSelectScalingMode: (CanvasScalingMode) -> Unit,
    onSelectExportResolution: (ExportResolutionTier) -> Unit,
    onUpdateVideoTransform: ((ClipTransform) -> ClipTransform) -> Unit,
    onUpdateColorGrade: ((ColorGradeConfig) -> ColorGradeConfig) -> Unit,
    onTextFocusChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(Color(0xFF141821))
            .border(1.dp, Color(0xFF222836))
    ) {
        // Inspector Tab Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF191E2B))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            InspectorTab.entries.forEach { tab ->
                val isSelected = activeTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) Color(0xFF6C5CE7) else Color.Transparent)
                        .clickable { onSelectTab(tab) }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab.title,
                        color = if (isSelected) Color.White else Color(0xFF9AA5B8),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        // Active Tab Body
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (activeTab) {
                InspectorTab.WHISTLE_CAPTIONS -> WhistleCaptionsTabContent(
                    sequence = sequence,
                    playheadMs = playheadMs,
                    whistleStatus = whistleStatus,
                    whistleLanguage = whistleLanguage,
                    whistleKeywords = whistleKeywords,
                    selectedCaptionPreset = selectedCaptionPreset,
                    isTranscribing = isTranscribing,
                    lastWhistleMetrics = lastWhistleMetrics,
                    onSelectLanguage = onSelectLanguage,
                    onSetAudioDepth = onSetAudioDepth,
                    onAddKeyword = onAddKeyword,
                    onRemoveKeyword = onRemoveKeyword,
                    onDownloadWhistleWeights = onDownloadWhistleWeights,
                    onTranscribeWithWhistle = onTranscribeWithWhistle,
                    onApplyCaptionPreset = onApplyCaptionPreset,
                    onUpdateCaptionText = onUpdateCaptionText,
                    onRippleCutWord = onRippleCutWord,
                    onSeekToMs = onSeekToMs,
                    onShowSubtitleExportDialog = onShowSubtitleExportDialog,
                    onTextFocusChanged = onTextFocusChanged
                )

                InspectorTab.RICH_TEXT -> RichTextTabContent(
                    selectedClip = selectedClip,
                    onAddNewRichTextClip = onAddNewRichTextClip,
                    onUpdateRichText = onUpdateRichText,
                    onTextFocusChanged = onTextFocusChanged
                )

                InspectorTab.VIDEO_COLOR -> VideoAndAspectTabContent(
                    sequence = sequence,
                    selectedClip = selectedClip,
                    onSelectAspectRatio = onSelectAspectRatio,
                    onSelectScalingMode = onSelectScalingMode,
                    onSelectExportResolution = onSelectExportResolution,
                    onUpdateVideoTransform = onUpdateVideoTransform,
                    onUpdateColorGrade = onUpdateColorGrade
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WhistleCaptionsTabContent(
    sequence: ProjectSequence,
    playheadMs: Long,
    whistleStatus: WhistleModelStatus,
    whistleLanguage: WhistleLanguage,
    whistleKeywords: List<String>,
    selectedCaptionPreset: CaptionStylePreset,
    isTranscribing: Boolean,
    lastWhistleMetrics: String,
    onSelectLanguage: (WhistleLanguage) -> Unit,
    onSetAudioDepth: (Int) -> Unit,
    onAddKeyword: (String) -> Unit,
    onRemoveKeyword: (String) -> Unit,
    onDownloadWhistleWeights: () -> Unit,
    onTranscribeWithWhistle: () -> Unit,
    onApplyCaptionPreset: (CaptionStylePreset) -> Unit,
    onUpdateCaptionText: (String, String) -> Unit,
    onRippleCutWord: (String, Int) -> Unit,
    onSeekToMs: (Long) -> Unit,
    onShowSubtitleExportDialog: () -> Unit,
    onTextFocusChanged: (Boolean) -> Unit
) {
    var newKeywordText by remember { mutableStateOf("") }

    // 1. Cactus Whistle Engine Status Card
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1B2232))
            .border(1.dp, Color(0xFF2D3954), RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CACTUS WHISTLE (16.9 MB ON-DEVICE)",
                color = Color(0xFF00FF88),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "CPU · No GPU",
                color = Color(0xFF00D2FF),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Text(
            text = whistleStatus.statusMessage,
            color = Color(0xFFD0D7E6),
            fontSize = 11.sp
        )
        Text(
            text = lastWhistleMetrics,
            color = Color(0xFF8A94A6),
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )

        if (whistleStatus.isDownloading) {
            LinearProgressIndicator(
                progress = { whistleStatus.downloadProgress },
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF00D2FF)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = onTranscribeWithWhistle,
                enabled = !isTranscribing,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isTranscribing) "Transcribing 16kHz..." else "⚡ Auto-Caption (Whistle)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onDownloadWhistleWeights,
                enabled = !whistleStatus.isDownloading,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF253047))
            ) {
                Text(text = "HF 16.9MB", fontSize = 10.sp)
            }
        }
    }

    // 2. Language Selection (7 Whistle Languages) & Decoder Ladder Depth (--audio-depth 2..8)
    SectionHeader("LANGUAGE & DECODER DEPTH (--audio-depth ${whistleStatus.selectedAudioDepth})")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        WhistleLanguage.entries.forEach { lang ->
            val selected = whistleLanguage == lang
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (selected) Color(0xFF00D2FF) else Color(0xFF222838))
                    .clickable { onSelectLanguage(lang) }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "${lang.badge} · ${lang.displayName.substringBefore(" ")}",
                    color = if (selected) Color(0xFF090B10) else Color(0xFFD0D7E6),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    SliderWithLabel(
        label = "Decoder Ladder Depth",
        valueText = "${whistleStatus.selectedAudioDepth} / 8 layers",
        value = whistleStatus.selectedAudioDepth.toFloat(),
        valueRange = 2f..8f,
        steps = 5,
        onValueChange = { onSetAudioDepth(it.toInt()) }
    )

    // 3. Aho-Corasick Keyword Biasing
    SectionHeader("AHO-CORASICK KEYWORD BIAS (PROPER NOUNS)")
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        OutlinedTextField(
            value = newKeywordText,
            onValueChange = { newKeywordText = it },
            placeholder = { Text("Add brand/name bias...", fontSize = 11.sp) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFF00D2FF),
                unfocusedBorderColor = Color(0xFF2E374D)
            ),
            modifier = Modifier
                .weight(1f)
                .onFocusChanged { onTextFocusChanged(it.isFocused) }
        )
        Button(
            onClick = {
                if (newKeywordText.isNotBlank()) {
                    onAddKeyword(newKeywordText)
                    newKeywordText = ""
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF28334A))
        ) {
            Text("+ Bias", fontSize = 11.sp)
        }
    }

    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        whistleKeywords.forEach { kw ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF232B3E))
                    .clickable { onRemoveKeyword(kw) }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "$kw ✕",
                    color = Color(0xFF00D2FF),
                    fontSize = 10.sp
                )
            }
        }
    }

    // 4. Kinetic Caption Style Presets
    SectionHeader("KINETIC CAPTION STYLE PRESETS")
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        CaptionStylePreset.entries.forEach { preset ->
            val isSelected = selectedCaptionPreset == preset
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) Color(0xFF6C5CE7) else Color(0xFF202636))
                    .border(
                        1.dp,
                        if (isSelected) Color(0xFF00D2FF) else Color(0xFF2E364A),
                        RoundedCornerShape(6.dp)
                    )
                    .clickable { onApplyCaptionPreset(preset) }
                    .padding(horizontal = 9.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "${preset.badge} · ${preset.displayName}",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }

    // 5. Interactive Word-Level Transcript & SRT/VTT Export
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        SectionHeader("WORD-ALIGNED TRANSCRIPT (CLICK WORD TO SEEK)")
        Text(
            text = "Export .SRT / .VTT",
            color = Color(0xFF00D2FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable { onShowSubtitleExportDialog() }
        )
    }

    val captionClips = sequence.tracks
        .filter { it.type == TrackType.CAPTION }
        .flatMap { it.clips }
        .sortedBy { it.timelineStartMs }

    captionClips.forEach { clip ->
        val cap = clip.captionData ?: return@forEach
        val isClipActive = clip.containsTime(playheadMs)

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(7.dp))
                .background(if (isClipActive) Color(0xFF222B40) else Color(0xFF1A202E))
                .border(
                    1.dp,
                    if (isClipActive) Color(0xFF00D2FF) else Color(0xFF283044),
                    RoundedCornerShape(7.dp)
                )
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${clip.timelineStartMs}ms → ${clip.timelineEndMs}ms",
                    color = Color(0xFF8A94A6),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Lang: ${cap.language.uppercase()}",
                    color = Color(0xFF00FF88),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Word chips with individual timestamps & ripple-cut action
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                cap.words.forEachIndexed { wIdx, w ->
                    val isWordSpoken = playheadMs in w.startMs..w.endMs
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .background(
                                if (isWordSpoken) Color(0xFF00FF88) else Color(0xFF283248)
                            )
                            .clickable { onSeekToMs(w.startMs) }
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = w.word,
                            color = if (isWordSpoken) Color(0xFF090B10) else Color.White,
                            fontSize = 11.sp,
                            fontWeight = if (isWordSpoken) FontWeight.Bold else FontWeight.Normal
                        )
                        Text(
                            text = "✂",
                            color = if (isWordSpoken) Color(0xFF090B10) else Color(0xFFFF7675),
                            fontSize = 9.sp,
                            modifier = Modifier.clickable { onRippleCutWord(clip.id, wIdx) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RichTextTabContent(
    selectedClip: TimelineClip?,
    onAddNewRichTextClip: () -> Unit,
    onUpdateRichText: ((RichTextSpec) -> RichTextSpec) -> Unit,
    onTextFocusChanged: (Boolean) -> Unit
) {
    val spec = selectedClip?.textData ?: selectedClip?.captionData?.richStyle

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        SectionHeader("RICH TEXT & TYPOGRAPHY ENGINE")
        Button(
            onClick = onAddNewRichTextClip,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7))
        ) {
            Text("+ Add Text (T)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }

    if (spec == null) {
        Text(
            text = "Select any Text (T1) or Caption (C1) clip on the timeline or press 'T' to create a Rich Text layer.",
            color = Color(0xFF8A94A6),
            fontSize = 12.sp
        )
        return
    }

    // 1. Live Text Content Field
    OutlinedTextField(
        value = spec.text,
        onValueChange = { updated -> onUpdateRichText { it.copy(text = updated) } },
        label = { Text("Layer Text Content", fontSize = 11.sp) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = Color(0xFF6C5CE7),
            unfocusedBorderColor = Color(0xFF2D364B)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { onTextFocusChanged(it.isFocused) }
    )

    // 2. Font Family Selector
    SectionHeader("FONT FAMILY")
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        EditorFontFamily.entries.forEach { font ->
            val selected = spec.fontFamily == font
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (selected) Color(0xFF6C5CE7) else Color(0xFF222838))
                    .clickable { onUpdateRichText { it.copy(fontFamily = font) } }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(
                    text = font.displayName,
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }

    // 3. Size, Weight, Tracking (Letter Spacing) & Leading (Line Height)
    SliderWithLabel(
        label = "Font Size",
        valueText = "${spec.fontSizeSp.toInt()} sp",
        value = spec.fontSizeSp,
        valueRange = 16f..96f,
        onValueChange = { v -> onUpdateRichText { it.copy(fontSizeSp = v) } }
    )

    SliderWithLabel(
        label = "Font Weight",
        valueText = "${spec.fontWeight}",
        value = spec.fontWeight.toFloat(),
        valueRange = 300f..900f,
        steps = 5,
        onValueChange = { v -> onUpdateRichText { it.copy(fontWeight = v.toInt()) } }
    )

    SliderWithLabel(
        label = "Letter Spacing (Tracking)",
        valueText = String.format("%.2f em", spec.letterSpacingEm),
        value = spec.letterSpacingEm,
        valueRange = -0.05f..0.35f,
        onValueChange = { v -> onUpdateRichText { it.copy(letterSpacingEm = v) } }
    )

    SliderWithLabel(
        label = "Line Height (Leading)",
        valueText = String.format("%.2fx", spec.lineHeightMultiplier),
        value = spec.lineHeightMultiplier,
        valueRange = 0.85f..1.8f,
        onValueChange = { v -> onUpdateRichText { it.copy(lineHeightMultiplier = v) } }
    )

    // 4. Case, Style Flags & Alignment Row
    SectionHeader("CASE, ALIGNMENT & STYLE FLAGS")
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        TextCaseMode.entries.forEach { mode ->
            val selected = spec.caseMode == mode
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (selected) Color(0xFF00D2FF) else Color(0xFF222838))
                    .clickable { onUpdateRichText { it.copy(caseMode = mode) } }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = mode.label,
                    color = if (selected) Color(0xFF090B10) else Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        TextAlignMode.entries.forEach { align ->
            val selected = spec.textAlign == align
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (selected) Color(0xFF6C5CE7) else Color(0xFF222838))
                    .clickable { onUpdateRichText { it.copy(textAlign = align) } }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = align.label,
                    color = Color.White,
                    fontSize = 10.sp
                )
            }
        }
    }

    // 5. Color Palette & Gradient Fill
    SectionHeader("TEXT FILL & GRADIENT PALETTE")
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextFillType.entries.forEach { ft ->
            val sel = spec.fillType == ft
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (sel) Color(0xFF6C5CE7) else Color(0xFF222838))
                    .clickable { onUpdateRichText { it.copy(fillType = ft) } }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(ft.label, color = Color.White, fontSize = 10.sp)
            }
        }
    }

    val colorSwatches = listOf(
        0xFFFFFFFFL, 0xFF00FF88L, 0xFF00D2FFL, 0xFFFFD32AL,
        0xFFFF5252L, 0xFFA855F7L, 0xFFFF79C6L, 0xFF0D0F14L
    )
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        colorSwatches.forEach { argb ->
            val isSelected = spec.primaryColorArgb == argb
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color(argb))
                    .border(
                        width = if (isSelected) 2.5.dp else 1.dp,
                        color = if (isSelected) Color(0xFF00D2FF) else Color(0xFF4A5568),
                        shape = CircleShape
                    )
                    .clickable { onUpdateRichText { it.copy(primaryColorArgb = argb) } }
            )
        }
    }

    // 6. Stroke, Drop Shadow & Background Pill Controls
    SectionHeader("STROKE, SHADOW & BACKGROUND PILL")
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Outline Stroke", color = Color(0xFFD0D7E6), fontSize = 11.sp)
        Switch(
            checked = spec.strokeEnabled,
            onCheckedChange = { en -> onUpdateRichText { it.copy(strokeEnabled = en) } }
        )
        Text("Bg Pill Box", color = Color(0xFFD0D7E6), fontSize = 11.sp)
        Switch(
            checked = spec.backgroundEnabled,
            onCheckedChange = { en -> onUpdateRichText { it.copy(backgroundEnabled = en) } }
        )
    }

    if (spec.strokeEnabled) {
        SliderWithLabel(
            label = "Stroke Width",
            valueText = "${spec.strokeWidthPx.toInt()} px",
            value = spec.strokeWidthPx,
            valueRange = 1f..24f,
            onValueChange = { v -> onUpdateRichText { it.copy(strokeWidthPx = v) } }
        )
    }

    if (spec.backgroundEnabled) {
        SliderWithLabel(
            label = "Pill Corner Radius",
            valueText = "${spec.backgroundCornerRadiusPx.toInt()} px",
            value = spec.backgroundCornerRadiusPx,
            valueRange = 0f..48f,
            onValueChange = { v -> onUpdateRichText { it.copy(backgroundCornerRadiusPx = v) } }
        )
    }

    SliderWithLabel(
        label = "Drop Shadow / Glow Blur",
        valueText = "${spec.shadowBlurPx.toInt()} px",
        value = spec.shadowBlurPx,
        valueRange = 0f..36f,
        onValueChange = { v ->
            onUpdateRichText { it.copy(shadowEnabled = v > 0.5f, shadowBlurPx = v) }
        }
    )

    // 7. Kinetic Animation Presets & Transform
    SectionHeader("MOTION & TRANSFORM")
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        TextAnimationPreset.entries.forEach { anim ->
            val sel = spec.animationPreset == anim
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (sel) Color(0xFF6C5CE7) else Color(0xFF222838))
                    .clickable { onUpdateRichText { it.copy(animationPreset = anim) } }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(anim.label, color = Color.White, fontSize = 10.sp)
            }
        }
    }

    SliderWithLabel(
        label = "Layer Scale",
        valueText = String.format("%.2fx", spec.scale),
        value = spec.scale,
        valueRange = 0.3f..2.5f,
        onValueChange = { v -> onUpdateRichText { it.copy(scale = v) } }
    )

    SliderWithLabel(
        label = "Rotation Angle",
        valueText = "${spec.rotationDeg.toInt()}°",
        value = spec.rotationDeg,
        valueRange = -180f..180f,
        onValueChange = { v -> onUpdateRichText { it.copy(rotationDeg = v) } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VideoAndAspectTabContent(
    sequence: ProjectSequence,
    selectedClip: TimelineClip?,
    onSelectAspectRatio: (AspectRatioPreset) -> Unit,
    onSelectScalingMode: (CanvasScalingMode) -> Unit,
    onSelectExportResolution: (ExportResolutionTier) -> Unit,
    onUpdateVideoTransform: ((ClipTransform) -> ClipTransform) -> Unit,
    onUpdateColorGrade: ((ColorGradeConfig) -> ColorGradeConfig) -> Unit
) {
    SectionHeader("SEQUENCE ASPECT RATIO & CANVAS FIT")
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        AspectRatioPreset.entries.forEach { preset ->
            val selected = sequence.aspectRatio == preset
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (selected) Color(0xFF6C5CE7) else Color(0xFF222838))
                    .clickable { onSelectAspectRatio(preset) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Column {
                    Text(
                        text = preset.label,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = preset.subtitle,
                        color = Color(0xFFB8C4D9),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }

    SectionHeader("CANVAS SCALING MODE")
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        CanvasScalingMode.entries.forEach { mode ->
            val selected = sequence.canvasScalingMode == mode
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (selected) Color(0xFF00D2FF) else Color(0xFF222838))
                    .clickable { onSelectScalingMode(mode) }
                    .padding(horizontal = 9.dp, vertical = 5.dp)
            ) {
                Text(
                    text = mode.label,
                    color = if (selected) Color(0xFF090B10) else Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    SectionHeader("EXPORT RESOLUTION TIER")
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        ExportResolutionTier.entries.forEach { tier ->
            val selected = sequence.exportResolution == tier
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (selected) Color(0xFF6C5CE7) else Color(0xFF222838))
                    .clickable { onSelectExportResolution(tier) }
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = tier.label.substringBefore(" "),
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    val transform = selectedClip?.transform ?: ClipTransform()
    val grade = selectedClip?.colorGrade ?: ColorGradeConfig()

    SectionHeader("CLIP TRANSFORM & COLOR GRADING")
    SliderWithLabel(
        label = "Clip Zoom Scale",
        valueText = String.format("%.2fx", transform.scale),
        value = transform.scale,
        valueRange = 0.5f..3.0f,
        onValueChange = { v -> onUpdateVideoTransform { it.copy(scale = v) } }
    )
    SliderWithLabel(
        label = "Rotation",
        valueText = "${transform.rotationDeg.toInt()}°",
        value = transform.rotationDeg,
        valueRange = -180f..180f,
        onValueChange = { v -> onUpdateVideoTransform { it.copy(rotationDeg = v) } }
    )
    SliderWithLabel(
        label = "Exposure",
        valueText = String.format("%+.2f EV", grade.exposure),
        value = grade.exposure,
        valueRange = -1.5f..1.5f,
        onValueChange = { v -> onUpdateColorGrade { it.copy(exposure = v) } }
    )
    SliderWithLabel(
        label = "Color Temperature",
        valueText = "${grade.temperature.toInt()}",
        value = grade.temperature,
        valueRange = -100f..100f,
        onValueChange = { v -> onUpdateColorGrade { it.copy(temperature = v) } }
    )
    SliderWithLabel(
        label = "Saturation",
        valueText = String.format("%.2fx", grade.saturation),
        value = grade.saturation,
        valueRange = 0f..2.0f,
        onValueChange = { v -> onUpdateColorGrade { it.copy(saturation = v) } }
    )
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        color = Color(0xFF8A94A6),
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun SliderWithLabel(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, color = Color(0xFFD0D7E6), fontSize = 11.sp)
            Text(
                text = valueText,
                color = Color(0xFF00D2FF),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF00D2FF),
                activeTrackColor = Color(0xFF6C5CE7),
                inactiveTrackColor = Color(0xFF283044)
            ),
            modifier = Modifier.height(24.dp)
        )
    }
}
