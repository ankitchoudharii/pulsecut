package com.pulsecut.pro.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsecut.pro.model.EditTool
import com.pulsecut.pro.model.ProjectSequence
import com.pulsecut.pro.model.TimelineClip
import com.pulsecut.pro.model.TimelineTrack
import com.pulsecut.pro.model.TrackType
import kotlin.math.roundToInt

@Composable
fun MultiTrackTimelinePanel(
    sequence: ProjectSequence,
    playheadMs: Long,
    activeTool: EditTool,
    selectedClipIds: Set<String>,
    zoomPxPerSec: Float,
    onSelectTool: (EditTool) -> Unit,
    onSelectClip: (String) -> Unit,
    onSeekToMs: (Long) -> Unit,
    onAdjustClipTiming: (String, Long, Long, Boolean, Boolean) -> Unit,
    onToggleTrackMute: (String) -> Unit,
    onToggleTrackLock: (String) -> Unit,
    onToggleTrackVisibility: (String) -> Unit,
    onToggleSnap: () -> Unit,
    onZoomChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val horizontalScroll = rememberScrollState()
    val verticalScroll = rememberScrollState()
    val density = LocalDensity.current

    val totalSeconds = (sequence.totalDurationMs / 1000f) + 6f
    val timelineWidthDp = (totalSeconds * zoomPxPerSec).dp.coerceAtLeast(700.dp)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF0E1118))
            .border(1.dp, Color(0xFF222836))
    ) {
        // 1. Left Premiere Pro Vertical Tool Dock
        Column(
            modifier = Modifier
                .width(52.dp)
                .fillMaxHeight()
                .background(Color(0xFF151924))
                .border(1.dp, Color(0xFF222836))
                .verticalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val primaryTools = listOf(
                EditTool.SELECTION_V,
                EditTool.RAZOR_C,
                EditTool.RIPPLE_EDIT_B,
                EditTool.ROLLING_EDIT_N,
                EditTool.SLIP_Y,
                EditTool.SLIDE_U,
                EditTool.TRACK_SELECT_A,
                EditTool.TYPE_T
            )
            primaryTools.forEach { tool ->
                val isSelected = activeTool == tool
                Box(
                    modifier = Modifier
                        .size(38.dp, 30.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) Color(0xFF6C5CE7) else Color(0xFF202636))
                        .clickable { onSelectTool(tool) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tool.shortcutKey,
                        color = if (isSelected) Color.White else Color(0xFFB8C4D9),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Snap toggle (S)
            Box(
                modifier = Modifier
                    .size(38.dp, 26.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(
                        if (sequence.magneticSnapEnabled) Color(0xFF173F4F) else Color(0xFF202636)
                    )
                    .clickable { onToggleSnap() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Snap",
                    color = if (sequence.magneticSnapEnabled) Color(0xFF00D2FF) else Color(0xFF7D8799),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 2. Track Headers Column
        Column(
            modifier = Modifier
                .width(148.dp)
                .fillMaxHeight()
                .background(Color(0xFF131722))
                .border(1.dp, Color(0xFF222836))
        ) {
            // Zoom & Snap Header Cell
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .background(Color(0xFF181D2B))
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "TRACKS",
                    color = Color(0xFF8A94A6),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "−",
                        color = Color(0xFF00D2FF),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onZoomChange(zoomPxPerSec / 1.25f) }
                    )
                    Text(
                        text = "+",
                        color = Color(0xFF00D2FF),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onZoomChange(zoomPxPerSec * 1.25f) }
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(verticalScroll)
            ) {
                sequence.tracks.forEach { track ->
                    TrackHeaderRow(
                        track = track,
                        onToggleMute = { onToggleTrackMute(track.id) },
                        onToggleLock = { onToggleTrackLock(track.id) },
                        onToggleVisibility = { onToggleTrackVisibility(track.id) }
                    )
                }
            }
        }

        // 3. Scrollable Multi-Track Timeline Canvas + Ruler + Playhead
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .horizontalScroll(horizontalScroll)
        ) {
            val pxPerMs = with(density) { (zoomPxPerSec.dp.toPx()) / 1000f }

            Column(
                modifier = Modifier
                    .width(timelineWidthDp)
                    .fillMaxHeight()
            ) {
                // Timecode Ruler (Click or Drag to Scrub Playhead)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .background(Color(0xFF171C28))
                        .pointerInput(pxPerMs) {
                            detectTapGestures { offset ->
                                val targetMs = (offset.x / pxPerMs).toLong().coerceAtLeast(0L)
                                onSeekToMs(targetMs)
                            }
                        }
                        .pointerInput(pxPerMs) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val targetMs = (change.position.x / pxPerMs).toLong().coerceAtLeast(0L)
                                onSeekToMs(targetMs)
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Draw In / Out work area highlight if set
                        val inMs = sequence.inPointMs
                        val outMs = sequence.outPointMs
                        if (inMs != null && outMs != null && outMs > inMs) {
                            drawRect(
                                color = Color(0x3300D2FF),
                                topLeft = Offset(inMs * pxPerMs, 0f),
                                size = androidx.compose.ui.geometry.Size((outMs - inMs) * pxPerMs, size.height)
                            )
                        }

                        // Draw second ticks
                        val totalSecsInt = totalSeconds.toInt()
                        for (sec in 0..totalSecsInt) {
                            val x = sec * 1000f * pxPerMs
                            drawLine(
                                color = Color(0xFF3E485E),
                                start = Offset(x, size.height - 10f),
                                end = Offset(x, size.height),
                                strokeWidth = 1.5f
                            )
                        }

                        // Draw Sequence Markers
                        sequence.markers.forEach { marker ->
                            val mx = marker.timeMs * pxPerMs
                            drawCircle(
                                color = Color(0xFF00D2FF),
                                radius = 5f,
                                center = Offset(mx, 8f)
                            )
                        }
                    }
                }

                // Track Lanes
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(verticalScroll)
                ) {
                    sequence.tracks.forEach { track ->
                        TimelineTrackLane(
                            track = track,
                            selectedClipIds = selectedClipIds,
                            zoomPxPerSec = zoomPxPerSec,
                            pxPerMs = pxPerMs,
                            onSelectClip = onSelectClip,
                            onAdjustClipTiming = onAdjustClipTiming
                        )
                    }
                }
            }

            // Red Playhead Line spanning full height
            val playheadOffsetDp = ((playheadMs / 1000f) * zoomPxPerSec).dp
            Box(
                modifier = Modifier
                    .offset(x = playheadOffsetDp)
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color(0xFFFF3B30))
            )
        }
    }
}

@Composable
private fun TrackHeaderRow(
    track: TimelineTrack,
    onToggleMute: () -> Unit,
    onToggleLock: () -> Unit,
    onToggleVisibility: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(track.heightDp.dp)
            .border(0.5.dp, Color(0xFF222836))
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.name,
                color = Color(0xFFD6DFEE),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${track.clips.size} clip(s)",
                color = Color(0xFF7D8799),
                fontSize = 9.sp
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            SmallTrackBtn(
                label = "M",
                active = track.isMuted,
                activeColor = Color(0xFFFF5252),
                onClick = onToggleMute
            )
            SmallTrackBtn(
                label = "L",
                active = track.isLocked,
                activeColor = Color(0xFFFFB142),
                onClick = onToggleLock
            )
            SmallTrackBtn(
                label = "V",
                active = track.isVisible,
                activeColor = Color(0xFF00D2FF),
                onClick = onToggleVisibility
            )
        }
    }
}

@Composable
private fun SmallTrackBtn(
    label: String,
    active: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(20.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (active) activeColor.copy(alpha = 0.25f) else Color(0xFF1E2433))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (active) activeColor else Color(0xFF7D8799),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TimelineTrackLane(
    track: TimelineTrack,
    selectedClipIds: Set<String>,
    zoomPxPerSec: Float,
    pxPerMs: Float,
    onSelectClip: (String) -> Unit,
    onAdjustClipTiming: (String, Long, Long, Boolean, Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(track.heightDp.dp)
            .background(Color(0xFF10141D))
            .border(0.5.dp, Color(0xFF1E2434))
    ) {
        track.clips.forEach { clip ->
            val startDp = ((clip.timelineStartMs / 1000f) * zoomPxPerSec).dp
            val widthDp = ((clip.durationMs / 1000f) * zoomPxPerSec).dp.coerceAtLeast(18.dp)
            val isSelected = selectedClipIds.contains(clip.id)
            val baseColor = Color(clip.clipColorArgb)

            Box(
                modifier = Modifier
                    .offset(x = startDp)
                    .width(widthDp)
                    .fillMaxHeight()
                    .padding(vertical = 3.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(baseColor.copy(alpha = 0.34f))
                    .border(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) Color(0xFF00FF88) else baseColor,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .clickable { onSelectClip(clip.id) }
                    .pointerInput(clip.id, pxPerMs) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaMs = (dragAmount.x / pxPerMs).toLong()
                            onAdjustClipTiming(clip.id, deltaMs, 0L, false, false)
                        }
                    }
            ) {
                // Render audio waveform or Whistle word-timestamp markers inside clip
                if (clip.trackType == TrackType.AUDIO && clip.waveformPeaks.isNotEmpty()) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val barCount = clip.waveformPeaks.size
                        val stepX = size.width / barCount.coerceAtLeast(1)
                        clip.waveformPeaks.forEachIndexed { idx, peak ->
                            val barH = size.height * peak.coerceIn(0.1f, 0.95f)
                            val x = idx * stepX
                            drawLine(
                                color = Color(0x8800D2FF),
                                start = Offset(x, (size.height - barH) / 2f),
                                end = Offset(x, (size.height + barH) / 2f),
                                strokeWidth = 2f
                            )
                        }
                    }
                } else if (clip.trackType == TrackType.CAPTION && clip.captionData != null) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        clip.captionData.words.forEach { w ->
                            val relX = (w.startMs - clip.timelineStartMs) * pxPerMs
                            if (relX in 0f..size.width) {
                                drawLine(
                                    color = Color(0x6600FF88),
                                    start = Offset(relX, size.height * 0.65f),
                                    end = Offset(relX, size.height),
                                    strokeWidth = 1.5f
                                )
                            }
                        }
                    }
                }

                // Clip Title & Trim Handles
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = clip.name,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    // Right Edge Trim Handle
                    Box(
                        modifier = Modifier
                            .width(10.dp)
                            .fillMaxHeight()
                            .background(Color(0x44FFFFFF))
                            .pointerInput(clip.id, pxPerMs) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val deltaDur = (dragAmount.x / pxPerMs).toLong()
                                    onAdjustClipTiming(clip.id, 0L, deltaDur, false, true)
                                }
                            }
                    )
                }
            }
        }
    }
}
