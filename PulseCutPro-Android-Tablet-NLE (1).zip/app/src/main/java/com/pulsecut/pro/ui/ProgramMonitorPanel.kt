package com.pulsecut.pro.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsecut.pro.model.AspectRatioPreset
import com.pulsecut.pro.model.CanvasScalingMode
import com.pulsecut.pro.model.ProjectSequence
import com.pulsecut.pro.model.TrackType
import com.pulsecut.pro.render.RichTextCanvasRenderer
import com.pulsecut.pro.viewmodel.EditorViewModel
import kotlin.math.abs

@Composable
fun ProgramMonitorPanel(
    sequence: ProjectSequence,
    playheadMs: Long,
    isPlaying: Boolean,
    shuttleSpeed: Float,
    selectedClipId: String?,
    onSelectAspectRatio: (AspectRatioPreset) -> Unit,
    onSelectScalingMode: (CanvasScalingMode) -> Unit,
    onToggleSafeZones: () -> Unit,
    onSelectClip: (String) -> Unit,
    onMoveOverlayNormalized: (String, Float, Float) -> Unit,
    onTogglePlayPause: () -> Unit,
    onShuttleReverseJ: () -> Unit,
    onShuttleStopK: () -> Unit,
    onShuttleForwardL: () -> Unit,
    onStepFrames: (Int) -> Unit,
    onSplitAtPlayhead: () -> Unit,
    onRippleTrimStartQ: () -> Unit,
    onRippleTrimEndW: () -> Unit,
    onMarkInI: () -> Unit,
    onMarkOutO: () -> Unit,
    modifier: Modifier = Modifier
) {
    var renderedBounds by remember {
        mutableStateOf<List<RichTextCanvasRenderer.RenderedOverlayBounds>>(emptyList())
    }
    var draggingClipId by remember { mutableStateOf<String?>(null) }
    var snapCenterX by remember { mutableStateOf(false) }
    var snapCenterY by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(Color(0xFF12151E))
            .border(1.dp, Color(0xFF222836))
    ) {
        // 1. Top Aspect Ratio & Scaling Mode Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF171B26))
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "ASPECT RATIO:",
                color = Color(0xFF8A94A6),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            AspectRatioPreset.entries.forEach { preset ->
                val isSelected = sequence.aspectRatio == preset
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isSelected) Color(0xFF6C5CE7) else Color(0xFF23293A)
                        )
                        .clickable { onSelectAspectRatio(preset) }
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = preset.label,
                        color = if (isSelected) Color.White else Color(0xFFC5CEE0),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Fit / Fill / Blurred Backdrop Mode Cycle Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1E2638))
                    .border(1.dp, Color(0xFF33415C), RoundedCornerShape(6.dp))
                    .clickable {
                        val modes = CanvasScalingMode.entries
                        val next = modes[(modes.indexOf(sequence.canvasScalingMode) + 1) % modes.size]
                        onSelectScalingMode(next)
                    }
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "Fit: ${sequence.canvasScalingMode.label}",
                    color = Color(0xFF00D2FF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Safe Zone Guide Toggle
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (sequence.showSafeZoneGuides) Color(0xFF1A3A4A) else Color(0xFF23293A)
                    )
                    .clickable { onToggleSafeZones() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (sequence.showSafeZoneGuides) "Guides: ON" else "Guides: OFF",
                    color = if (sequence.showSafeZoneGuides) Color(0xFF00D2FF) else Color(0xFF8A94A6),
                    fontSize = 11.sp
                )
            }
        }

        // 2. Center Dynamic Aspect-Ratio Canvas Viewport
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF090B10))
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            val density = LocalDensity.current
            val availW = maxWidth
            val availH = maxHeight
            val targetAspect = sequence.aspectRatio.aspectRatioFloat
            val containerAspect = availW.value / availH.value.coerceAtLeast(1f)

            val (viewportW, viewportH) = if (containerAspect > targetAspect) {
                (availH * targetAspect) to availH
            } else {
                availW to (availW / targetAspect)
            }

            val viewportWidthPx = with(density) { viewportW.toPx() }.coerceAtLeast(1f)
            val viewportHeightPx = with(density) { viewportH.toPx() }.coerceAtLeast(1f)

            val visibleTracks = sequence.tracks.filter { it.isVisible && !it.isMuted }
            val activeVideoClips = visibleTracks
                .filter { it.type == TrackType.VIDEO }
                .flatMap { it.clips }
                .filter { it.containsTime(playheadMs) }

            val activeOverlayClips = visibleTracks
                .filter { it.type == TrackType.TEXT || it.type == TrackType.CAPTION }
                .flatMap { it.clips }
                .filter { it.containsTime(playheadMs) }

            Box(
                modifier = Modifier
                    .size(viewportW, viewportH)
                    .border(1.5.dp, Color(0xFF2E364F), RoundedCornerShape(4.dp))
                    .clip(RoundedCornerShape(4.dp))
                    .pointerInput(activeOverlayClips, viewportWidthPx, viewportHeightPx) {
                        detectTapGestures { tapOffset ->
                            val hit = renderedBounds.lastOrNull { b ->
                                b.rect.contains(tapOffset.x, tapOffset.y)
                            }
                            if (hit != null) {
                                onSelectClip(hit.clipId)
                            }
                        }
                    }
                    .pointerInput(activeOverlayClips, viewportWidthPx, viewportHeightPx) {
                        detectDragGestures(
                            onDragStart = { startOffset ->
                                val hit = renderedBounds.lastOrNull { b ->
                                    b.rect.contains(startOffset.x, startOffset.y)
                                } ?: renderedBounds.lastOrNull()
                                draggingClipId = hit?.clipId
                                if (hit != null) onSelectClip(hit.clipId)
                            },
                            onDragEnd = {
                                draggingClipId = null
                                snapCenterX = false
                                snapCenterY = false
                            },
                            onDragCancel = {
                                draggingClipId = null
                                snapCenterX = false
                                snapCenterY = false
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val targetId = draggingClipId ?: return@detectDragGestures
                                val normX = (change.position.x / viewportWidthPx).coerceIn(0.05f, 0.95f)
                                val normY = (change.position.y / viewportHeightPx).coerceIn(0.05f, 0.95f)
                                snapCenterX = abs(normX - 0.5f) < 0.025f
                                snapCenterY = abs(normY - 0.5f) < 0.025f
                                onMoveOverlayNormalized(targetId, normX, normY)
                            }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    renderedBounds = RichTextCanvasRenderer.renderSequenceFrame(
                        canvas = drawContext.canvas.nativeCanvas,
                        canvasWidth = size.width,
                        canvasHeight = size.height,
                        playheadMs = playheadMs,
                        aspectRatio = sequence.aspectRatio,
                        scalingMode = sequence.canvasScalingMode,
                        activeVideoClips = activeVideoClips,
                        activeOverlayClips = activeOverlayClips,
                        selectedClipId = selectedClipId,
                        showSafeZones = sequence.showSafeZoneGuides,
                        showSnapGuidesX = snapCenterX,
                        showSnapGuidesY = snapCenterY,
                        drawSelectionHandles = true
                    )
                }

                // Aspect ratio & resolution watermark pill in top-left of monitor
                val (expW, expH) = sequence.aspectRatio.computeExportDimensions(sequence.exportResolution.shortEdgePx)
                Surface(
                    color = Color(0xAA0D0F14),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                ) {
                    Text(
                        text = "${sequence.aspectRatio.label} · ${expW}x${expH}",
                        color = Color(0xFFD0D7E6),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        // 3. Bottom Premiere Pro Transport & Shuttle Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF161A24))
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Timecode Display + Shuttle Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = EditorViewModel.formatTimecode(playheadMs, sequence.fps),
                    color = Color(0xFF00D2FF),
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "/ ${EditorViewModel.formatTimecode(sequence.totalDurationMs, sequence.fps)}",
                    color = Color(0xFF7D8799),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                if (shuttleSpeed != 0f) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF6C5CE7))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${if (shuttleSpeed > 0) "+" else ""}${shuttleSpeed.toInt()}x",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Center: J / K / L Shuttle & Frame Step Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TransportButton(label = "I", tooltip = "Mark In", onClick = onMarkInI)
                TransportButton(label = "O", tooltip = "Mark Out", onClick = onMarkOutO)
                TransportButton(label = "◀|", tooltip = "-1f", onClick = { onStepFrames(-1) })
                TransportButton(label = "⏪ J", tooltip = "Shuttle Reverse", onClick = onShuttleReverseJ)
                TransportButton(
                    label = if (isPlaying) "⏸ K" else "▶ Space",
                    tooltip = "Play / Pause",
                    isPrimary = true,
                    onClick = onTogglePlayPause
                )
                TransportButton(label = "L ⏩", tooltip = "Shuttle Forward", onClick = onShuttleForwardL)
                TransportButton(label = "|▶", tooltip = "+1f", onClick = { onStepFrames(1) })
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Right: Premiere Pro Q / Ctrl+K / W Quick Trim & Split Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TransportButton(label = "[Q Ripple", tooltip = "Ripple Trim Prev", onClick = onRippleTrimStartQ)
                TransportButton(label = "✂ Split (Ctrl+K)", tooltip = "Add Edit", onClick = onSplitAtPlayhead)
                TransportButton(label = "Ripple W]", tooltip = "Ripple Trim Next", onClick = onRippleTrimEndW)
            }
        }
    }
}

@Composable
private fun TransportButton(
    label: String,
    tooltip: String,
    isPrimary: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(5.dp))
            .background(if (isPrimary) Color(0xFF6C5CE7) else Color(0xFF23293A))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isPrimary) Color.White else Color(0xFFD6DFEE),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
