package com.pulsecut.pro.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsecut.pro.shortcuts.PremiereShortcutManager
import com.pulsecut.pro.viewmodel.EditorViewModel

@Composable
fun TabletWorkspaceScreen(
    viewModel: EditorViewModel,
    onPickExternalMedia: () -> Unit,
    onTextFocusChanged: (Boolean) -> Unit
) {
    val sequence by viewModel.sequence.collectAsState()
    val playheadMs by viewModel.playheadMs.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val shuttleSpeed by viewModel.shuttleSpeed.collectAsState()
    val activeTool by viewModel.activeTool.collectAsState()
    val selectedClipIds by viewModel.selectedClipIds.collectAsState()
    val activeInspectorTab by viewModel.activeInspectorTab.collectAsState()
    val zoomPxPerSec by viewModel.timelineZoomPxPerSec.collectAsState()
    val whistleStatus by viewModel.whistleStatus.collectAsState()
    val whistleLanguage by viewModel.whistleLanguage.collectAsState()
    val whistleKeywords by viewModel.whistleKeywords.collectAsState()
    val selectedCaptionPreset by viewModel.selectedCaptionPreset.collectAsState()
    val isTranscribing by viewModel.isTranscribing.collectAsState()
    val lastWhistleMetrics by viewModel.lastWhistleMetrics.collectAsState()
    val showShortcutsModal by viewModel.showShortcutsModal.collectAsState()
    val statusBanner by viewModel.statusBanner.collectAsState()
    val sourceAssets by viewModel.sourceAssets.collectAsState()
    val activeSourceId by viewModel.activeSourceAssetId.collectAsState()
    val exportState by viewModel.exportState.collectAsState()

    var showSubtitleDialog by remember { mutableStateOf(false) }

    val primarySelectedClip = remember(sequence, selectedClipIds) {
        viewModel.getPrimarySelectedClip()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0F14))
    ) {
        // 1. Top Studio Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .background(Color(0xFF151922))
                .border(1.dp, Color(0xFF23293A))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "PULSECUT PRO",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF1F293D))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Cactus Whistle 16.9MB · Premiere Keymap",
                        color = Color(0xFF00FF88),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = statusBanner,
                    color = Color(0xFF9AA5B8),
                    fontSize = 11.sp
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                HeaderActionButton("↶ Undo", onClick = { viewModel.undo() })
                HeaderActionButton("↷ Redo", onClick = { viewModel.redo() })
                HeaderActionButton(
                    "⌨ Shortcuts (?)",
                    onClick = { viewModel.setShowShortcutsModal(true) }
                )
                Button(
                    onClick = { viewModel.exportProjectMp4() },
                    enabled = !exportState.isExporting,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF))
                ) {
                    Text(
                        text = if (exportState.isExporting) {
                            "Exporting ${(exportState.progress * 100).toInt()}%"
                        } else {
                            "Export ${sequence.aspectRatio.label} MP4"
                        },
                        color = Color(0xFF090B10),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (exportState.isExporting) {
            LinearProgressIndicator(
                progress = { exportState.progress },
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF00FF88)
            )
        }

        // 2. Upper 3-Pane Tablet Workspace (Source/Media Bin + Program Monitor + Inspector)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.56f)
        ) {
            // Left Pane: Project Media Bin & 3-Point Source Editing
            Column(
                modifier = Modifier
                    .weight(0.22f)
                    .fillMaxHeight()
                    .background(Color(0xFF131722))
                    .border(1.dp, Color(0xFF222836))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PROJECT BIN & 3-PT",
                        color = Color(0xFF8A94A6),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "+ Import Video",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onPickExternalMedia() }
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    sourceAssets.forEach { asset ->
                        val isSelected = asset.id == activeSourceId
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (isSelected) Color(0xFF232C42) else Color(0xFF1A1F2E)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) Color(0xFF6C5CE7) else Color(0xFF262D40),
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { viewModel.selectSourceAsset(asset.id) }
                                .padding(7.dp)
                        ) {
                            Text(
                                text = asset.name,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${asset.nativeAspect.label} · ${asset.durationMs / 1000}s",
                                color = Color(0xFF8A94A6),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // 3-Point Insert (,) and Overwrite (.) buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFF252E42))
                            .clickable { viewModel.insertOrOverwriteFromSource(insertRipple = true) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Insert (,)", color = Color(0xFF00D2FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFF6C5CE7))
                            .clickable { viewModel.insertOrOverwriteFromSource(insertRipple = false) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Overwrite (.)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Center Pane: Program Monitor with Aspect Ratio Switcher & Direct Text Canvas
            ProgramMonitorPanel(
                sequence = sequence,
                playheadMs = playheadMs,
                isPlaying = isPlaying,
                shuttleSpeed = shuttleSpeed,
                selectedClipId = primarySelectedClip?.id,
                onSelectAspectRatio = viewModel::setAspectRatio,
                onSelectScalingMode = viewModel::setCanvasScalingMode,
                onToggleSafeZones = viewModel::toggleSafeZones,
                onSelectClip = { viewModel.selectClip(it) },
                onMoveOverlayNormalized = viewModel::moveOverlayNormalized,
                onTogglePlayPause = viewModel::togglePlayPause,
                onShuttleReverseJ = viewModel::stepShuttleReverseJ,
                onShuttleStopK = viewModel::stopShuttleK,
                onShuttleForwardL = viewModel::stepShuttleForwardL,
                onStepFrames = viewModel::stepFrames,
                onSplitAtPlayhead = { viewModel.splitClipsAtPlayhead(allTracks = false) },
                onRippleTrimStartQ = { viewModel.rippleTrimToPlayhead(trimStart = true) },
                onRippleTrimEndW = { viewModel.rippleTrimToPlayhead(trimStart = false) },
                onMarkInI = { viewModel.setSequenceInPoint(playheadMs) },
                onMarkOutO = { viewModel.setSequenceOutPoint(playheadMs) },
                modifier = Modifier.weight(0.46f)
            )

            // Right Pane: Captions (Cactus Whistle), Rich Text & Video/Aspect Inspector
            InspectorTabsPanel(
                activeTab = activeInspectorTab,
                onSelectTab = viewModel::setActiveInspectorTab,
                sequence = sequence,
                selectedClip = primarySelectedClip,
                playheadMs = playheadMs,
                whistleStatus = whistleStatus,
                whistleLanguage = whistleLanguage,
                whistleKeywords = whistleKeywords,
                selectedCaptionPreset = selectedCaptionPreset,
                isTranscribing = isTranscribing,
                lastWhistleMetrics = lastWhistleMetrics,
                onSelectLanguage = viewModel::setWhistleLanguage,
                onSetAudioDepth = viewModel::setWhistleAudioDepth,
                onAddKeyword = viewModel::addBiasKeyword,
                onRemoveKeyword = viewModel::removeBiasKeyword,
                onDownloadWhistleWeights = viewModel::downloadWhistleWeightsFromHf,
                onTranscribeWithWhistle = viewModel::transcribeTimelineWithWhistle,
                onApplyCaptionPreset = viewModel::applyCaptionPresetToAll,
                onUpdateCaptionText = viewModel::updateCaptionSegmentText,
                onRippleCutWord = viewModel::rippleCutWordFromTranscript,
                onSeekToMs = viewModel::seekTo,
                onShowSubtitleExportDialog = { showSubtitleDialog = true },
                onAddNewRichTextClip = viewModel::addNewRichTextClipAtPlayhead,
                onUpdateRichText = viewModel::updateSelectedRichText,
                onSelectAspectRatio = viewModel::setAspectRatio,
                onSelectScalingMode = viewModel::setCanvasScalingMode,
                onSelectExportResolution = viewModel::setExportResolution,
                onUpdateVideoTransform = viewModel::updateSelectedVideoTransform,
                onUpdateColorGrade = viewModel::updateSelectedColorGrade,
                onTextFocusChanged = onTextFocusChanged,
                modifier = Modifier.weight(0.32f)
            )
        }

        // 3. Lower Multi-Track Timeline Dock
        MultiTrackTimelinePanel(
            sequence = sequence,
            playheadMs = playheadMs,
            activeTool = activeTool,
            selectedClipIds = selectedClipIds,
            zoomPxPerSec = zoomPxPerSec,
            onSelectTool = viewModel::selectEditTool,
            onSelectClip = { viewModel.selectClip(it) },
            onSeekToMs = viewModel::seekTo,
            onAdjustClipTiming = viewModel::adjustClipTiming,
            onToggleTrackMute = viewModel::toggleTrackMute,
            onToggleTrackLock = viewModel::toggleTrackLock,
            onToggleTrackVisibility = viewModel::toggleTrackVisibility,
            onToggleSnap = viewModel::toggleMagneticSnap,
            onZoomChange = viewModel::setTimelineZoom,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.44f)
        )
    }

    // Premiere Pro Hardware Keyboard Shortcuts Modal
    if (showShortcutsModal) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowShortcutsModal(false) },
            containerColor = Color(0xFF161A26),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFD0D7E6),
            title = {
                Text(
                    "Adobe Premiere Pro Hardware Keyboard Shortcuts",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PremiereShortcutManager.ALL_PREMIERE_SHORTCUTS.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1F2637))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.actionName,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = item.description,
                                    color = Color(0xFF9AA5B8),
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = Color(0xFF6C5CE7),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = item.keyCombo,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.setShowShortcutsModal(false) }) {
                    Text("Close", color = Color(0xFF00D2FF))
                }
            }
        )
    }

    // SRT / WebVTT Subtitle Export Preview Dialog
    if (showSubtitleDialog) {
        val srtText = remember(sequence) { viewModel.exportSubtitlesAsSrt() }
        val vttText = remember(sequence) { viewModel.exportSubtitlesAsVtt() }
        var showVtt by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showSubtitleDialog = false },
            containerColor = Color(0xFF161A26),
            titleContentColor = Color.White,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (showVtt) "WebVTT (.vtt Word-Synced)" else "SubRip (.srt) Captions",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { showVtt = !showVtt }) {
                        Text(
                            if (showVtt) "Switch to .SRT" else "Switch to .VTT",
                            color = Color(0xFF00D2FF)
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF0D0F14))
                        .padding(10.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = if (showVtt) vttText else srtText,
                        color = Color(0xFF00FF88),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showSubtitleDialog = false }) {
                    Text("Done", color = Color(0xFF00D2FF))
                }
            }
        )
    }
}

@Composable
private fun HeaderActionButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(5.dp))
            .background(Color(0xFF23293A))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Text(
            text = label,
            color = Color(0xFFD6DFEE),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
