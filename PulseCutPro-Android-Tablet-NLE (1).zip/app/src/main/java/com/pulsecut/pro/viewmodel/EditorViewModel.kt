package com.pulsecut.pro.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pulsecut.pro.model.AspectRatioPreset
import com.pulsecut.pro.model.CanvasScalingMode
import com.pulsecut.pro.model.CaptionSegmentSpec
import com.pulsecut.pro.model.CaptionStylePreset
import com.pulsecut.pro.model.ClipTransform
import com.pulsecut.pro.model.ColorGradeConfig
import com.pulsecut.pro.model.EditTool
import com.pulsecut.pro.model.EditorFontFamily
import com.pulsecut.pro.model.ExportResolutionTier
import com.pulsecut.pro.model.ProjectSequence
import com.pulsecut.pro.model.RichTextSpec
import com.pulsecut.pro.model.SequenceMarker
import com.pulsecut.pro.model.SourceMonitorAsset
import com.pulsecut.pro.model.TextAnimationPreset
import com.pulsecut.pro.model.TextCaseMode
import com.pulsecut.pro.model.TimelineClip
import com.pulsecut.pro.model.TimelineTrack
import com.pulsecut.pro.model.TrackType
import com.pulsecut.pro.render.ExportJobState
import com.pulsecut.pro.render.VideoExportEngine
import com.pulsecut.pro.shortcuts.PremiereCommand
import com.pulsecut.pro.speech.AudioTrackExtractor
import com.pulsecut.pro.speech.SubtitleFormatIO
import com.pulsecut.pro.speech.WhistleLanguage
import com.pulsecut.pro.speech.WhistleModelManager
import com.pulsecut.pro.speech.WhistleModelStatus
import com.pulsecut.pro.speech.WhistleWordTimestamp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToLong

enum class InspectorTab(val title: String) {
    WHISTLE_CAPTIONS("Captions (Whistle)"),
    RICH_TEXT("Rich Text"),
    VIDEO_COLOR("Video & Aspect")
}

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val whistleModelManager = WhistleModelManager(application)
    private val audioExtractor = AudioTrackExtractor(application)
    private val exportEngine = VideoExportEngine(application)

    val whistleStatus: StateFlow<WhistleModelStatus> = whistleModelManager.status
    val exportState: StateFlow<ExportJobState> = exportEngine.state

    // Undo / Redo Command History
    private val undoStack = ArrayDeque<ProjectSequence>()
    private val redoStack = ArrayDeque<ProjectSequence>()

    private val _sequence = MutableStateFlow(createInitialDemoSequence())
    val sequence: StateFlow<ProjectSequence> = _sequence.asStateFlow()

    private val _playheadMs = MutableStateFlow(1_200L)
    val playheadMs: StateFlow<Long> = _playheadMs.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    // Premiere Pro J/K/L Shuttle Speed (-4f, -2f, -1f, 0f, +1f, +2f, +4f)
    private val _shuttleSpeed = MutableStateFlow(0f)
    val shuttleSpeed: StateFlow<Float> = _shuttleSpeed.asStateFlow()

    private val _activeTool = MutableStateFlow(EditTool.SELECTION_V)
    val activeTool: StateFlow<EditTool> = _activeTool.asStateFlow()

    private val _selectedClipIds = MutableStateFlow<Set<String>>(setOf("clip_cap_1"))
    val selectedClipIds: StateFlow<Set<String>> = _selectedClipIds.asStateFlow()

    private val _activeInspectorTab = MutableStateFlow(InspectorTab.WHISTLE_CAPTIONS)
    val activeInspectorTab: StateFlow<InspectorTab> = _activeInspectorTab.asStateFlow()

    private val _timelineZoomPxPerSec = MutableStateFlow(92f)
    val timelineZoomPxPerSec: StateFlow<Float> = _timelineZoomPxPerSec.asStateFlow()

    // Cactus Whistle Transcription Options
    private val _whistleLanguage = MutableStateFlow(WhistleLanguage.AUTO)
    val whistleLanguage: StateFlow<WhistleLanguage> = _whistleLanguage.asStateFlow()

    private val _whistleKeywords = MutableStateFlow(
        listOf("PulseCut Pro", "Cactus Whistle", "Premiere Pro", "Android Tablet", "Needle")
    )
    val whistleKeywords: StateFlow<List<String>> = _whistleKeywords.asStateFlow()

    private val _selectedCaptionPreset = MutableStateFlow(CaptionStylePreset.HORMOZI_BOLD)
    val selectedCaptionPreset: StateFlow<CaptionStylePreset> = _selectedCaptionPreset.asStateFlow()

    private val _isTranscribing = MutableStateFlow(false)
    val isTranscribing: StateFlow<Boolean> = _isTranscribing.asStateFlow()

    private val _lastWhistleMetrics = MutableStateFlow("16.9 MB · 11.1 ms TTFT · 1,319 tok/s CPU")
    val lastWhistleMetrics: StateFlow<String> = _lastWhistleMetrics.asStateFlow()

    private val _showShortcutsModal = MutableStateFlow(false)
    val showShortcutsModal: StateFlow<Boolean> = _showShortcutsModal.asStateFlow()

    private val _statusBanner = MutableStateFlow("Premiere Pro Keymap Active · Press '?' for Shortcuts")
    val statusBanner: StateFlow<String> = _statusBanner.asStateFlow()

    private val _sourceAssets = MutableStateFlow(createDefaultSourceBin())
    val sourceAssets: StateFlow<List<SourceMonitorAsset>> = _sourceAssets.asStateFlow()

    private val _activeSourceAssetId = MutableStateFlow("src_1")
    val activeSourceAssetId: StateFlow<String> = _activeSourceAssetId.asStateFlow()

    private var playbackJob: Job? = null

    init {
        viewModelScope.launch {
            whistleModelManager.initializeModel(audioDepth = 8)
        }
    }

    // =========================================================================
    // Premiere Pro Hardware Keyboard Command Execution
    // =========================================================================

    fun executePremiereCommand(cmd: PremiereCommand) {
        when (cmd) {
            PremiereCommand.TogglePlayPause -> togglePlayPause()
            PremiereCommand.ShuttleReverseJ -> stepShuttleReverseJ()
            PremiereCommand.ShuttleStopK -> stopShuttleK()
            PremiereCommand.ShuttleForwardL -> stepShuttleForwardL()
            is PremiereCommand.StepFrames -> stepFrames(cmd.deltaFrames)
            PremiereCommand.JumpToStart -> seekTo(0L)
            PremiereCommand.JumpToEnd -> seekTo(_sequence.value.totalDurationMs)
            PremiereCommand.JumpToPreviousEdit -> jumpToAdjacentEditPoint(forward = false)
            PremiereCommand.JumpToNextEdit -> jumpToAdjacentEditPoint(forward = true)
            is PremiereCommand.SelectTool -> selectEditTool(cmd.tool)
            is PremiereCommand.SplitAtPlayhead -> splitClipsAtPlayhead(cmd.allTracks)
            PremiereCommand.RippleTrimPreviousToPlayheadQ -> rippleTrimToPlayhead(trimStart = true)
            PremiereCommand.RippleTrimNextToPlayheadW -> rippleTrimToPlayhead(trimStart = false)
            PremiereCommand.MarkInPointI -> setSequenceInPoint(_playheadMs.value)
            PremiereCommand.MarkOutPointO -> setSequenceOutPoint(_playheadMs.value)
            PremiereCommand.MarkClipX -> markSelectedClipInOut()
            PremiereCommand.ClearInOutPoints -> clearInOutPoints()
            PremiereCommand.InsertFromSourceComma -> insertOrOverwriteFromSource(insertRipple = true)
            PremiereCommand.OverwriteFromSourcePeriod -> insertOrOverwriteFromSource(insertRipple = false)
            PremiereCommand.AddMarkerM -> addSequenceMarkerAtPlayhead()
            PremiereCommand.LiftDelete -> deleteSelectedClips(ripple = false)
            PremiereCommand.RippleDelete -> deleteSelectedClips(ripple = true)
            PremiereCommand.Undo -> undo()
            PremiereCommand.Redo -> redo()
            PremiereCommand.DuplicateClip -> duplicateSelectedClip()
            PremiereCommand.ToggleSnapS -> toggleMagneticSnap()
            PremiereCommand.ZoomInTimeline -> setTimelineZoom(_timelineZoomPxPerSec.value * 1.25f)
            PremiereCommand.ZoomOutTimeline -> setTimelineZoom(_timelineZoomPxPerSec.value / 1.25f)
            PremiereCommand.ZoomFitTimeline -> setTimelineZoom(75f)
            PremiereCommand.CycleAspectRatio -> cycleAspectRatio()
            PremiereCommand.TranscribeWithWhistle -> transcribeTimelineWithWhistle()
            PremiereCommand.ToggleShortcutsModal -> {
                _showShortcutsModal.value = !_showShortcutsModal.value
            }
        }
    }

    // =========================================================================
    // Transport & J / K / L Shuttle Loop
    // =========================================================================

    fun togglePlayPause() {
        if (_isPlaying.value) {
            stopShuttleK()
        } else {
            startShuttleWithSpeed(1.0f)
        }
    }

    fun stepShuttleReverseJ() {
        val current = _shuttleSpeed.value
        val next = when {
            current > 0f -> -1f
            current == 0f -> -1f
            current == -1f -> -2f
            else -> -4f
        }
        startShuttleWithSpeed(next)
        _statusBanner.value = "Shuttle Reverse ${next}x (J)"
    }

    fun stopShuttleK() {
        _shuttleSpeed.value = 0f
        _isPlaying.value = false
        playbackJob?.cancel()
        _statusBanner.value = "Shuttle Pause (K)"
    }

    fun stepShuttleForwardL() {
        val current = _shuttleSpeed.value
        val next = when {
            current < 0f -> 1f
            current == 0f -> 1f
            current == 1f -> 2f
            else -> 4f
        }
        startShuttleWithSpeed(next)
        _statusBanner.value = "Shuttle Forward +${next}x (L)"
    }

    private fun startShuttleWithSpeed(speed: Float) {
        _shuttleSpeed.value = speed
        _isPlaying.value = (speed != 0f)
        playbackJob?.cancel()
        if (speed == 0f) return

        playbackJob = viewModelScope.launch {
            val tickMs = 16L
            while (_isPlaying.value) {
                delay(tickMs)
                val delta = (tickMs * speed).roundToLong()
                val maxDur = _sequence.value.totalDurationMs
                val nextPos = (_playheadMs.value + delta).coerceIn(0L, maxDur)
                _playheadMs.value = nextPos
                if ((speed > 0 && nextPos >= maxDur) || (speed < 0 && nextPos <= 0L)) {
                    stopShuttleK()
                    break
                }
            }
        }
    }

    fun seekTo(timeMs: Long) {
        val maxDur = _sequence.value.totalDurationMs
        _playheadMs.value = timeMs.coerceIn(0L, maxDur)
    }

    fun stepFrames(deltaFrames: Int) {
        stopShuttleK()
        val frameMs = _sequence.value.frameDurationMs
        seekTo(_playheadMs.value + deltaFrames * frameMs)
    }

    fun jumpToAdjacentEditPoint(forward: Boolean) {
        val cur = _playheadMs.value
        val cutPoints = _sequence.value.tracks
            .filter { !it.isLocked }
            .flatMap { it.clips }
            .flatMap { listOf(it.timelineStartMs, it.timelineEndMs) }
            .distinct()
            .sorted()

        val target = if (forward) {
            cutPoints.firstOrNull { it > cur + 5L } ?: _sequence.value.totalDurationMs
        } else {
            cutPoints.lastOrNull { it < cur - 5L } ?: 0L
        }
        seekTo(target)
        _statusBanner.value = "Jumped to Edit Point @ ${formatTimecode(target)}"
    }

    // =========================================================================
    // Aspect Ratio & Canvas Scaling Controls
    // =========================================================================

    fun setAspectRatio(preset: AspectRatioPreset) {
        pushUndoSnapshot()
        val updatedTracks = _sequence.value.tracks.map { track ->
            if (track.type == TrackType.CAPTION) {
                track.copy(
                    clips = track.clips.map { clip ->
                        val cap = clip.captionData
                        if (cap != null) {
                            val newStyle = cap.richStyle.copy(
                                normalizedY = preset.defaultCaptionNormalizedY
                            )
                            clip.copy(
                                captionData = cap.copy(richStyle = newStyle),
                                textData = newStyle
                            )
                        } else clip
                    }
                )
            } else track
        }
        _sequence.value = _sequence.value.copy(
            aspectRatio = preset,
            tracks = updatedTracks
        )
        val (w, h) = preset.computeExportDimensions(_sequence.value.exportResolution.shortEdgePx)
        _statusBanner.value = "Aspect Ratio set to ${preset.label} (${preset.subtitle} · ${w}x${h})"
    }

    fun cycleAspectRatio() {
        val all = AspectRatioPreset.entries
        val nextIdx = (all.indexOf(_sequence.value.aspectRatio) + 1) % all.size
        setAspectRatio(all[nextIdx])
    }

    fun setCanvasScalingMode(mode: CanvasScalingMode) {
        pushUndoSnapshot()
        _sequence.value = _sequence.value.copy(canvasScalingMode = mode)
        _statusBanner.value = "Canvas Fit Mode: ${mode.label}"
    }

    fun setExportResolution(tier: ExportResolutionTier) {
        _sequence.value = _sequence.value.copy(exportResolution = tier)
        val (w, h) = _sequence.value.aspectRatio.computeExportDimensions(tier.shortEdgePx)
        _statusBanner.value = "Export Target: ${tier.label} (${w}x${h} @ ${tier.bitrateMbps} Mbps)"
    }

    fun toggleSafeZones() {
        _sequence.value = _sequence.value.copy(
            showSafeZoneGuides = !_sequence.value.showSafeZoneGuides
        )
    }

    // =========================================================================
    // Premiere Pro Editing Operations (Razor, Ripple, Roll, Slip, Slide, Q/W)
    // =========================================================================

    fun selectEditTool(tool: EditTool) {
        _activeTool.value = tool
        _statusBanner.value = "${tool.displayName} (${tool.shortcutKey}) — ${tool.description}"
        if (tool == EditTool.TYPE_T) {
            addNewRichTextClipAtPlayhead()
            _activeInspectorTab.value = InspectorTab.RICH_TEXT
        }
    }

    fun selectClip(clipId: String, multiSelect: Boolean = false) {
        val current = _selectedClipIds.value
        val clip = findClipById(clipId)

        if (_activeTool.value == EditTool.RAZOR_C && clip != null) {
            splitSpecificClipAtTime(clipId, _playheadMs.value)
            return
        }

        if (_activeTool.value == EditTool.TRACK_SELECT_A && clip != null) {
            val forwardIds = _sequence.value.tracks
                .filter { !it.isLocked }
                .flatMap { it.clips }
                .filter { it.timelineStartMs >= clip.timelineStartMs }
                .map { it.id }
                .toSet()
            _selectedClipIds.value = forwardIds
            _statusBanner.value = "Track Select Forward (A): ${forwardIds.size} clips selected"
            return
        }

        _selectedClipIds.value = if (multiSelect) {
            if (current.contains(clipId)) current - clipId else current + clipId
        } else {
            setOf(clipId)
        }

        when (clip?.trackType) {
            TrackType.CAPTION -> _activeInspectorTab.value = InspectorTab.WHISTLE_CAPTIONS
            TrackType.TEXT -> _activeInspectorTab.value = InspectorTab.RICH_TEXT
            TrackType.VIDEO -> _activeInspectorTab.value = InspectorTab.VIDEO_COLOR
            else -> {}
        }
    }

    fun splitClipsAtPlayhead(allTracks: Boolean = false) {
        val cutTime = _playheadMs.value
        val selected = _selectedClipIds.value
        var splitCount = 0

        pushUndoSnapshot()
        val newTracks = _sequence.value.tracks.map { track ->
            if (track.isLocked) return@map track
            val newClips = ArrayList<TimelineClip>()
            for (clip in track.clips) {
                val shouldSplit = (allTracks || selected.isEmpty() || selected.contains(clip.id)) &&
                    cutTime > clip.timelineStartMs + 120L &&
                    cutTime < clip.timelineEndMs - 120L

                if (shouldSplit) {
                    splitCount++
                    val leftDur = cutTime - clip.timelineStartMs
                    val rightDur = clip.durationMs - leftDur

                    val leftCaption = clip.captionData?.let { cap ->
                        val leftWords = cap.words.filter { it.endMs <= cutTime }
                        cap.copy(
                            rawText = leftWords.joinToString(" ") { it.word }.ifBlank { cap.rawText },
                            words = leftWords
                        )
                    }
                    val rightCaption = clip.captionData?.let { cap ->
                        val rightWords = cap.words.filter { it.startMs >= cutTime }
                        cap.copy(
                            rawText = rightWords.joinToString(" ") { it.word }.ifBlank { cap.rawText },
                            words = rightWords
                        )
                    }

                    val leftClip = clip.copy(
                        durationMs = leftDur,
                        captionData = leftCaption
                    )
                    val rightClip = clip.copy(
                        id = "${clip.id}_cut_${cutTime}",
                        name = "${clip.name} (2)",
                        timelineStartMs = cutTime,
                        durationMs = rightDur,
                        sourceInMs = clip.sourceInMs + leftDur,
                        captionData = rightCaption
                    )
                    newClips.add(leftClip)
                    newClips.add(rightClip)
                } else {
                    newClips.add(clip)
                }
            }
            track.copy(clips = newClips)
        }

        if (splitCount > 0) {
            _sequence.value = _sequence.value.copy(tracks = newTracks)
            _statusBanner.value = "Razor / Add Edit (Ctrl+K): Split $splitCount clip(s) @ ${formatTimecode(cutTime)}"
        } else {
            _statusBanner.value = "No active clip under playhead to split"
        }
    }

    fun splitSpecificClipAtTime(clipId: String, cutTimeMs: Long) {
        _selectedClipIds.value = setOf(clipId)
        val prevPlayhead = _playheadMs.value
        _playheadMs.value = cutTimeMs
        splitClipsAtPlayhead(allTracks = false)
        _playheadMs.value = prevPlayhead
    }

    /**
     * Premiere Pro 'Q' (Ripple Trim Previous Edit to Playhead) and 'W' (Ripple Trim Next Edit to Playhead).
     */
    fun rippleTrimToPlayhead(trimStart: Boolean) {
        val cutTime = _playheadMs.value
        pushUndoSnapshot()
        var trimmed = false

        val newTracks = _sequence.value.tracks.map { track ->
            if (track.isLocked) return@map track
            val targetIdx = track.clips.indexOfFirst { it.containsTime(cutTime) }
            if (targetIdx < 0) return@map track

            val target = track.clips[targetIdx]
            val mutable = track.clips.toMutableList()

            if (trimStart) {
                // 'Q' — Trim start of clip up to playhead and ripple everything left by delta
                val delta = cutTime - target.timelineStartMs
                if (delta > 60L && target.durationMs - delta >= 200L) {
                    trimmed = true
                    mutable[targetIdx] = target.copy(
                        durationMs = target.durationMs - delta,
                        sourceInMs = target.sourceInMs + delta
                    )
                    for (i in targetIdx + 1 until mutable.size) {
                        val c = mutable[i]
                        mutable[i] = c.copy(timelineStartMs = (c.timelineStartMs - delta).coerceAtLeast(0L))
                    }
                    _playheadMs.value = target.timelineStartMs
                }
            } else {
                // 'W' — Trim end of clip back to playhead and ripple downstream clips left
                val delta = target.timelineEndMs - cutTime
                if (delta > 60L && cutTime - target.timelineStartMs >= 200L) {
                    trimmed = true
                    mutable[targetIdx] = target.copy(
                        durationMs = cutTime - target.timelineStartMs
                    )
                    for (i in targetIdx + 1 until mutable.size) {
                        val c = mutable[i]
                        mutable[i] = c.copy(timelineStartMs = (c.timelineStartMs - delta).coerceAtLeast(0L))
                    }
                }
            }
            track.copy(clips = mutable)
        }

        if (trimmed) {
            _sequence.value = _sequence.value.copy(tracks = newTracks)
            _statusBanner.value = if (trimStart) {
                "Ripple Trim Start to Playhead (Q)"
            } else {
                "Ripple Trim End to Playhead (W)"
            }
        }
    }

    /**
     * Unified timeline drag & trim handler supporting Selection (V), Ripple (B), Rolling (N),
     * Slip (Y), and Slide (U) tools.
     */
    fun adjustClipTiming(
        clipId: String,
        deltaStartMs: Long,
        deltaDurationMs: Long,
        isLeftEdgeTrim: Boolean = false,
        isRightEdgeTrim: Boolean = false
    ) {
        val tool = _activeTool.value
        val newTracks = _sequence.value.tracks.map { track ->
            if (track.isLocked) return@map track
            val idx = track.clips.indexOfFirst { it.id == clipId }
            if (idx < 0) return@map track

            val clip = track.clips[idx]
            val list = track.clips.toMutableList()

            when {
                // SLIP TOOL (Y): Shifts sourceInMs while timelineStartMs & durationMs stay fixed
                tool == EditTool.SLIP_Y -> {
                    val newSourceIn = (clip.sourceInMs + deltaStartMs)
                        .coerceIn(0L, (clip.sourceDurationMs - clip.durationMs).coerceAtLeast(0L))
                    list[idx] = clip.copy(sourceInMs = newSourceIn)
                }

                // SLIDE TOOL (U): Moves clip while trimming adjacent left and right neighbors
                tool == EditTool.SLIDE_U -> {
                    val prev = list.getOrNull(idx - 1)
                    val next = list.getOrNull(idx + 1)
                    val clampedDelta = deltaStartMs.coerceIn(
                        -(prev?.durationMs?.minus(200L) ?: clip.timelineStartMs),
                        next?.durationMs?.minus(200L) ?: 30_000L
                    )
                    if (prev != null) {
                        list[idx - 1] = prev.copy(durationMs = prev.durationMs + clampedDelta)
                    }
                    if (next != null) {
                        list[idx + 1] = next.copy(
                            timelineStartMs = next.timelineStartMs + clampedDelta,
                            durationMs = next.durationMs - clampedDelta,
                            sourceInMs = next.sourceInMs + clampedDelta
                        )
                    }
                    list[idx] = clip.copy(
                        timelineStartMs = (clip.timelineStartMs + clampedDelta).coerceAtLeast(0L)
                    )
                }

                // ROLLING EDIT (N): Moves shared boundary between clip and its neighbor
                tool == EditTool.ROLLING_EDIT_N && isRightEdgeTrim && idx + 1 < list.size -> {
                    val next = list[idx + 1]
                    val rollDelta = deltaDurationMs.coerceIn(
                        -(clip.durationMs - 200L),
                        next.durationMs - 200L
                    )
                    list[idx] = clip.copy(durationMs = clip.durationMs + rollDelta)
                    list[idx + 1] = next.copy(
                        timelineStartMs = next.timelineStartMs + rollDelta,
                        durationMs = next.durationMs - rollDelta,
                        sourceInMs = next.sourceInMs + rollDelta
                    )
                }

                // RIPPLE EDIT (B): Trims clip and shifts all downstream clips on the same track
                tool == EditTool.RIPPLE_EDIT_B && (isRightEdgeTrim || isLeftEdgeTrim) -> {
                    val newDur = (clip.durationMs + deltaDurationMs).coerceAtLeast(200L)
                    val actualDelta = newDur - clip.durationMs
                    list[idx] = clip.copy(durationMs = newDur)
                    for (i in idx + 1 until list.size) {
                        val downstream = list[i]
                        list[i] = downstream.copy(
                            timelineStartMs = (downstream.timelineStartMs + actualDelta).coerceAtLeast(0L)
                        )
                    }
                }

                // STANDARD MOVE OR TRIM (V)
                else -> {
                    val rawStart = (clip.timelineStartMs + deltaStartMs).coerceAtLeast(0L)
                    val snappedStart = if (_sequence.value.magneticSnapEnabled && deltaStartMs != 0L) {
                        snapTimeToPlayheadOrCuts(rawStart, clip.id)
                    } else rawStart
                    val newDur = (clip.durationMs + deltaDurationMs).coerceAtLeast(200L)
                    list[idx] = clip.copy(
                        timelineStartMs = snappedStart,
                        durationMs = newDur
                    )
                }
            }
            track.copy(clips = list)
        }
        _sequence.value = _sequence.value.copy(tracks = newTracks)
    }

    fun deleteSelectedClips(ripple: Boolean) {
        val selected = _selectedClipIds.value
        if (selected.isEmpty()) return
        pushUndoSnapshot()

        val newTracks = _sequence.value.tracks.map { track ->
            if (track.isLocked) return@map track
            val remaining = ArrayList<TimelineClip>()
            var rippleShiftAcc = 0L

            for (clip in track.clips.sortedBy { it.timelineStartMs }) {
                if (selected.contains(clip.id)) {
                    if (ripple) rippleShiftAcc += clip.durationMs
                } else {
                    remaining.add(
                        clip.copy(
                            timelineStartMs = (clip.timelineStartMs - rippleShiftAcc).coerceAtLeast(0L)
                        )
                    )
                }
            }
            track.copy(clips = remaining)
        }

        _sequence.value = _sequence.value.copy(tracks = newTracks)
        _selectedClipIds.value = emptySet()
        _statusBanner.value = if (ripple) "Ripple Deleted clip(s) (Shift+Del)" else "Lift Deleted clip(s) (Del)"
    }

    fun duplicateSelectedClip() {
        val target = getPrimarySelectedClip() ?: return
        pushUndoSnapshot()
        val copyId = "${target.id}_dup_${System.currentTimeMillis() % 10000}"
        val duplicate = target.copy(
            id = copyId,
            name = "${target.name} Copy",
            timelineStartMs = target.timelineEndMs
        )
        val newTracks = _sequence.value.tracks.map { track ->
            if (track.id == target.trackId) {
                track.copy(clips = track.clips + duplicate)
            } else track
        }
        _sequence.value = _sequence.value.copy(tracks = newTracks)
        _selectedClipIds.value = setOf(copyId)
        _statusBanner.value = "Duplicated '${target.name}' (Ctrl+D)"
    }

    // =========================================================================
    // 3-Point Source Monitor Editing (I, O, X, Comma Insert, Period Overwrite)
    // =========================================================================

    fun selectSourceAsset(assetId: String) {
        _activeSourceAssetId.value = assetId
    }

    fun insertOrOverwriteFromSource(insertRipple: Boolean) {
        val src = _sourceAssets.value.firstOrNull { it.id == _activeSourceAssetId.value }
            ?: _sourceAssets.value.firstOrNull() ?: return
        val insertTime = _sequence.value.inPointMs ?: _playheadMs.value
        val clipDur = (src.outPointMs - src.inPointMs).coerceAtLeast(1000L)

        pushUndoSnapshot()
        val newClipId = "vclip_${System.currentTimeMillis() % 100000}"
        val newClip = TimelineClip(
            id = newClipId,
            name = src.name,
            trackId = "V1",
            trackType = TrackType.VIDEO,
            mediaUri = src.mediaUri,
            timelineStartMs = insertTime,
            durationMs = clipDur,
            sourceInMs = src.inPointMs,
            sourceDurationMs = src.durationMs,
            spokenTranscriptHint = src.defaultTranscriptHint
        )

        val newTracks = _sequence.value.tracks.map { track ->
            if (track.id != "V1") return@map track
            val updated = if (insertRipple) {
                track.clips.map { existing ->
                    if (existing.timelineStartMs >= insertTime) {
                        existing.copy(timelineStartMs = existing.timelineStartMs + clipDur)
                    } else existing
                } + newClip
            } else {
                track.clips.filterNot {
                    it.timelineStartMs >= insertTime && it.timelineEndMs <= insertTime + clipDur
                } + newClip
            }
            track.copy(clips = updated.sortedBy { it.timelineStartMs })
        }

        _sequence.value = _sequence.value.copy(tracks = newTracks)
        _selectedClipIds.value = setOf(newClipId)
        _playheadMs.value = insertTime + clipDur
        _statusBanner.value = if (insertRipple) {
            "Inserted '${src.name}' (,) @ ${formatTimecode(insertTime)}"
        } else {
            "Overwrote '${src.name}' (.) @ ${formatTimecode(insertTime)}"
        }
    }

    fun importExternalMediaUri(uriString: String, displayName: String) {
        val assetId = "src_${System.currentTimeMillis() % 100000}"
        val newAsset = SourceMonitorAsset(
            id = assetId,
            name = displayName,
            mediaUri = uriString,
            durationMs = 10_000L,
            inPointMs = 0L,
            outPointMs = 10_000L,
            defaultTranscriptHint = "Imported tablet footage ready for Cactus Whistle transcription and Premiere Pro editing"
        )
        _sourceAssets.value = _sourceAssets.value + newAsset
        _activeSourceAssetId.value = assetId
        insertOrOverwriteFromSource(insertRipple = false)
    }

    fun setSequenceInPoint(timeMs: Long) {
        _sequence.value = _sequence.value.copy(inPointMs = timeMs)
        _statusBanner.value = "Marked Sequence In (I) @ ${formatTimecode(timeMs)}"
    }

    fun setSequenceOutPoint(timeMs: Long) {
        _sequence.value = _sequence.value.copy(outPointMs = timeMs)
        _statusBanner.value = "Marked Sequence Out (O) @ ${formatTimecode(timeMs)}"
    }

    fun markSelectedClipInOut() {
        val clip = getPrimarySelectedClip() ?: return
        _sequence.value = _sequence.value.copy(
            inPointMs = clip.timelineStartMs,
            outPointMs = clip.timelineEndMs
        )
        _statusBanner.value = "Marked Clip In/Out (X): ${formatTimecode(clip.timelineStartMs)} - ${formatTimecode(clip.timelineEndMs)}"
    }

    fun clearInOutPoints() {
        _sequence.value = _sequence.value.copy(inPointMs = null, outPointMs = null)
        _statusBanner.value = "Cleared In/Out Points (Alt+I/O)"
    }

    fun addSequenceMarkerAtPlayhead() {
        val time = _playheadMs.value
        val marker = SequenceMarker(
            id = "m_${time}",
            timeMs = time,
            label = "Marker ${_sequence.value.markers.size + 1}"
        )
        _sequence.value = _sequence.value.copy(markers = _sequence.value.markers + marker)
        _statusBanner.value = "Added Marker (M) @ ${formatTimecode(time)}"
    }

    // =========================================================================
    // Cactus Whistle On-Device Speech-to-Text & Caption Pipeline
    // =========================================================================

    fun setWhistleLanguage(lang: WhistleLanguage) {
        _whistleLanguage.value = lang
        _statusBanner.value = "Whistle Language set to ${lang.displayName}"
    }

    fun setWhistleAudioDepth(depth: Int) {
        whistleModelManager.setAudioDepth(depth)
    }

    fun addBiasKeyword(keyword: String) {
        val trimmed = keyword.trim()
        if (trimmed.isNotEmpty() && !_whistleKeywords.value.contains(trimmed)) {
            _whistleKeywords.value = _whistleKeywords.value + trimmed
            _statusBanner.value = "Added Aho-Corasick Bias Keyword: '$trimmed'"
        }
    }

    fun removeBiasKeyword(keyword: String) {
        _whistleKeywords.value = _whistleKeywords.value - keyword
    }

    fun downloadWhistleWeightsFromHf() {
        viewModelScope.launch {
            whistleModelManager.downloadFromHuggingFace()
        }
    }

    /**
     * Runs Cactus Whistle across all unlocked V1/A1 clips, extracts 16 kHz mono PCM,
     * aligns word-level timestamps, and populates Caption Track C1 with kinetic segments.
     */
    fun transcribeTimelineWithWhistle() {
        if (_isTranscribing.value) return
        viewModelScope.launch {
            _isTranscribing.value = true
            _statusBanner.value = "Running Cactus Whistle (16 kHz Log-Mel · 5 Beams · Aho-Corasick Keyword Bias)..."
            try {
                val modelPath = whistleModelManager.initializeModel(
                    audioDepth = whistleStatus.value.selectedAudioDepth
                )
                val videoClips = _sequence.value.tracks
                    .firstOrNull { it.id == "V1" }
                    ?.clips
                    ?.sortedBy { it.timelineStartMs }
                    ?: emptyList()

                val generatedCaptionClips = ArrayList<TimelineClip>()
                val preset = _selectedCaptionPreset.value
                val defaultY = _sequence.value.aspectRatio.defaultCaptionNormalizedY
                var lastTtft = 11.1f
                var lastTps = 1319.0f

                for ((clipIdx, vClip) in videoClips.withIndex()) {
                    val pcm16k = audioExtractor.decodeClipTo16kMono(
                        mediaUri = vClip.mediaUri,
                        sourceInMs = vClip.sourceInMs,
                        durationMs = vClip.durationMs
                    )
                    val transcriptResult = audioExtractor.transcribeClipWindowed(
                        modelPath = modelPath,
                        samples16k = pcm16k,
                        timelineStartMs = vClip.timelineStartMs,
                        language = _whistleLanguage.value,
                        audioDepth = whistleStatus.value.selectedAudioDepth,
                        beamSize = 5,
                        keywords = _whistleKeywords.value,
                        transcriptHint = vClip.spokenTranscriptHint
                    )

                    lastTtft = transcriptResult.ttftMs
                    lastTps = transcriptResult.decodeTokensPerSec

                    if (!transcriptResult.isSilence && transcriptResult.words.isNotEmpty()) {
                        // Group words into punchy 4-to-5 word caption segments
                        val chunks = transcriptResult.words.chunked(4)
                        chunks.forEachIndexed { chunkIdx, wordChunk ->
                            val segStart = wordChunk.first().startMs
                            val segEnd = wordChunk.last().endMs.coerceAtLeast(segStart + 450L)
                            val segText = wordChunk.joinToString(" ") { it.word }
                            val spec = CaptionSegmentSpec.fromPreset(
                                rawText = segText,
                                language = transcriptResult.language,
                                words = wordChunk,
                                preset = preset,
                                normalizedY = defaultY
                            )
                            generatedCaptionClips.add(
                                TimelineClip(
                                    id = "whistle_cap_${clipIdx}_${chunkIdx}_${segStart}",
                                    name = segText,
                                    trackId = "C1",
                                    trackType = TrackType.CAPTION,
                                    timelineStartMs = segStart,
                                    durationMs = segEnd - segStart,
                                    sourceInMs = 0L,
                                    sourceDurationMs = segEnd - segStart,
                                    captionData = spec,
                                    textData = spec.richStyle
                                )
                            )
                        }
                    }
                }

                if (generatedCaptionClips.isNotEmpty()) {
                    pushUndoSnapshot()
                    val updatedTracks = _sequence.value.tracks.map { track ->
                        if (track.id == "C1") {
                            track.copy(clips = generatedCaptionClips)
                        } else track
                    }
                    _sequence.value = _sequence.value.copy(tracks = updatedTracks)
                    _selectedClipIds.value = setOf(generatedCaptionClips.first().id)
                    _lastWhistleMetrics.value = String.format(
                        "Whistle: %.1f ms TTFT · %.0f tok/s · %d words aligned",
                        lastTtft,
                        lastTps,
                        generatedCaptionClips.sumOf { it.captionData?.words?.size ?: 0 }
                    )
                    _statusBanner.value = "Generated ${generatedCaptionClips.size} Kinetic Caption Segments via Cactus Whistle"
                }
            } finally {
                _isTranscribing.value = false
            }
        }
    }

    fun applyCaptionPresetToAll(preset: CaptionStylePreset) {
        _selectedCaptionPreset.value = preset
        pushUndoSnapshot()
        val normY = _sequence.value.aspectRatio.defaultCaptionNormalizedY
        val updatedTracks = _sequence.value.tracks.map { track ->
            if (track.type != TrackType.CAPTION) return@map track
            track.copy(
                clips = track.clips.map { clip ->
                    val cap = clip.captionData ?: return@map clip
                    val updatedCap = CaptionSegmentSpec.fromPreset(
                        rawText = cap.rawText,
                        language = cap.language,
                        words = cap.words,
                        preset = preset,
                        normalizedY = normY
                    )
                    clip.copy(
                        captionData = updatedCap,
                        textData = updatedCap.richStyle
                    )
                }
            )
        }
        _sequence.value = _sequence.value.copy(tracks = updatedTracks)
        _statusBanner.value = "Applied '${preset.displayName}' style to all Whistle captions"
    }

    fun updateCaptionSegmentText(clipId: String, newText: String) {
        val tokens = newText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return
        pushUndoSnapshot()

        val updatedTracks = _sequence.value.tracks.map { track ->
            if (track.type != TrackType.CAPTION) return@map track
            track.copy(
                clips = track.clips.map { clip ->
                    if (clip.id != clipId) return@map clip
                    val cap = clip.captionData ?: return@map clip
                    val slotMs = (clip.durationMs / tokens.size.coerceAtLeast(1)).coerceAtLeast(80L)
                    val newWords = tokens.mapIndexed { idx, w ->
                        WhistleWordTimestamp(
                            word = w,
                            startMs = clip.timelineStartMs + idx * slotMs,
                            endMs = (clip.timelineStartMs + (idx + 1) * slotMs).coerceAtMost(clip.timelineEndMs),
                            probability = 0.99f
                        )
                    }
                    val updatedStyle = cap.richStyle.copy(text = newText)
                    clip.copy(
                        name = newText.take(24),
                        captionData = cap.copy(
                            rawText = newText,
                            words = newWords,
                            richStyle = updatedStyle
                        ),
                        textData = updatedStyle
                    )
                }
            )
        }
        _sequence.value = _sequence.value.copy(tracks = updatedTracks)
    }

    /**
     * Transcript-driven video editing: removes a word (and its time span) from the caption
     * and optionally ripple-cuts the underlying video clip!
     */
    fun rippleCutWordFromTranscript(clipId: String, wordIndex: Int) {
        val clip = findClipById(clipId) ?: return
        val cap = clip.captionData ?: return
        val targetWord = cap.words.getOrNull(wordIndex) ?: return

        pushUndoSnapshot()
        val remainingWords = cap.words.filterIndexed { idx, _ -> idx != wordIndex }
        val newRawText = remainingWords.joinToString(" ") { it.word }

        val updatedTracks = _sequence.value.tracks.map { track ->
            if (track.id != clip.trackId) return@map track
            track.copy(
                clips = track.clips.mapNotNull { c ->
                    if (c.id != clipId) c
                    else if (remainingWords.isEmpty()) null
                    else c.copy(
                        name = newRawText.take(24),
                        captionData = cap.copy(
                            rawText = newRawText,
                            words = remainingWords,
                            richStyle = cap.richStyle.copy(text = newRawText)
                        )
                    )
                }
            )
        }
        _sequence.value = _sequence.value.copy(tracks = updatedTracks)
        _statusBanner.value = "Removed '${targetWord.word}' (${targetWord.startMs}ms..${targetWord.endMs}ms) from transcript"
    }

    fun exportSubtitlesAsSrt(): String {
        val captionClips = _sequence.value.tracks
            .filter { it.type == TrackType.CAPTION }
            .flatMap { it.clips }
        return SubtitleFormatIO.exportToSrt(captionClips)
    }

    fun exportSubtitlesAsVtt(): String {
        val captionClips = _sequence.value.tracks
            .filter { it.type == TrackType.CAPTION }
            .flatMap { it.clips }
        return SubtitleFormatIO.exportToWebVtt(captionClips, includeWordTags = true)
    }

    fun importSrtContent(srtContent: String) {
        val imported = SubtitleFormatIO.parseSrtToClips(
            srtContent = srtContent,
            trackId = "C1",
            stylePreset = _selectedCaptionPreset.value
        )
        if (imported.isEmpty()) return
        pushUndoSnapshot()
        val updatedTracks = _sequence.value.tracks.map { track ->
            if (track.id == "C1") track.copy(clips = imported) else track
        }
        _sequence.value = _sequence.value.copy(tracks = updatedTracks)
        _statusBanner.value = "Imported ${imported.size} SRT subtitle cues into Track C1"
    }

    // =========================================================================
    // Rich Text Creation & Styling Mutations
    // =========================================================================

    fun addNewRichTextClipAtPlayhead() {
        pushUndoSnapshot()
        val start = _playheadMs.value
        val newId = "text_${System.currentTimeMillis() % 100000}"
        val spec = RichTextSpec(
            text = "TABLET PRO TITLE",
            fontFamily = EditorFontFamily.MONTSERRAT_HEAVY,
            fontSizeSp = 44f,
            fontWeight = 900,
            normalizedX = 0.5f,
            normalizedY = 0.24f,
            primaryColorArgb = 0xFFFFFFFF,
            secondaryColorArgb = 0xFF00D2FF,
            strokeEnabled = true,
            strokeColorArgb = 0xFF0D0F14,
            strokeWidthPx = 9f,
            backgroundEnabled = true,
            backgroundColorArgb = 0xCC161B26,
            backgroundCornerRadiusPx = 20f,
            animationPreset = TextAnimationPreset.FADE_UP_WORDS
        )
        val newClip = TimelineClip(
            id = newId,
            name = spec.text,
            trackId = "T1",
            trackType = TrackType.TEXT,
            timelineStartMs = start,
            durationMs = 3_500L,
            textData = spec
        )
        val updatedTracks = _sequence.value.tracks.map { track ->
            if (track.id == "T1") track.copy(clips = track.clips + newClip) else track
        }
        _sequence.value = _sequence.value.copy(tracks = updatedTracks)
        _selectedClipIds.value = setOf(newId)
        _activeInspectorTab.value = InspectorTab.RICH_TEXT
        _statusBanner.value = "Added Rich Text Layer on Track T1"
    }

    fun updateSelectedRichText(transform: (RichTextSpec) -> RichTextSpec) {
        val selected = _selectedClipIds.value
        if (selected.isEmpty()) return

        val updatedTracks = _sequence.value.tracks.map { track ->
            track.copy(
                clips = track.clips.map { clip ->
                    if (!selected.contains(clip.id)) return@map clip
                    val currentSpec = clip.textData ?: clip.captionData?.richStyle ?: return@map clip
                    val nextSpec = transform(currentSpec)
                    val nextCaption = clip.captionData?.copy(
                        rawText = nextSpec.text,
                        richStyle = nextSpec
                    )
                    clip.copy(
                        name = nextSpec.text.take(24),
                        textData = nextSpec,
                        captionData = nextCaption
                    )
                }
            )
        }
        _sequence.value = _sequence.value.copy(tracks = updatedTracks)
    }

    fun moveOverlayNormalized(clipId: String, normX: Float, normY: Float) {
        val clampedX = normX.coerceIn(0.05f, 0.95f)
        val clampedY = normY.coerceIn(0.05f, 0.95f)
        // Magnetic snap to center axes (0.5f)
        val finalX = if (abs(clampedX - 0.5f) < 0.022f) 0.5f else clampedX
        val finalY = if (abs(clampedY - 0.5f) < 0.022f) 0.5f else clampedY

        _selectedClipIds.value = setOf(clipId)
        updateSelectedRichText { spec ->
            spec.copy(normalizedX = finalX, normalizedY = finalY)
        }
    }

    fun updateSelectedVideoTransform(transform: (ClipTransform) -> ClipTransform) {
        val selected = _selectedClipIds.value
        val updatedTracks = _sequence.value.tracks.map { track ->
            track.copy(
                clips = track.clips.map { clip ->
                    if (selected.contains(clip.id)) {
                        clip.copy(transform = transform(clip.transform))
                    } else clip
                }
            )
        }
        _sequence.value = _sequence.value.copy(tracks = updatedTracks)
    }

    fun updateSelectedColorGrade(transform: (ColorGradeConfig) -> ColorGradeConfig) {
        val selected = _selectedClipIds.value
        val updatedTracks = _sequence.value.tracks.map { track ->
            track.copy(
                clips = track.clips.map { clip ->
                    if (selected.contains(clip.id)) {
                        clip.copy(colorGrade = transform(clip.colorGrade))
                    } else clip
                }
            )
        }
        _sequence.value = _sequence.value.copy(tracks = updatedTracks)
    }

    // =========================================================================
    // Track Header Controls, Zoom, Undo/Redo, and MP4 Export
    // =========================================================================

    fun toggleTrackMute(trackId: String) {
        _sequence.value = _sequence.value.copy(
            tracks = _sequence.value.tracks.map {
                if (it.id == trackId) it.copy(isMuted = !it.isMuted) else it
            }
        )
    }

    fun toggleTrackLock(trackId: String) {
        _sequence.value = _sequence.value.copy(
            tracks = _sequence.value.tracks.map {
                if (it.id == trackId) it.copy(isLocked = !it.isLocked) else it
            }
        )
    }

    fun toggleTrackVisibility(trackId: String) {
        _sequence.value = _sequence.value.copy(
            tracks = _sequence.value.tracks.map {
                if (it.id == trackId) it.copy(isVisible = !it.isVisible) else it
            }
        )
    }

    fun toggleMagneticSnap() {
        val next = !_sequence.value.magneticSnapEnabled
        _sequence.value = _sequence.value.copy(magneticSnapEnabled = next)
        _statusBanner.value = if (next) "Magnetic Snapping Enabled (S)" else "Magnetic Snapping Disabled (S)"
    }

    fun setTimelineZoom(pxPerSec: Float) {
        _timelineZoomPxPerSec.value = pxPerSec.coerceIn(32f, 260f)
    }

    fun setActiveInspectorTab(tab: InspectorTab) {
        _activeInspectorTab.value = tab
    }

    fun setShowShortcutsModal(visible: Boolean) {
        _showShortcutsModal.value = visible
    }

    fun exportProjectMp4() {
        if (exportState.value.isExporting) return
        stopShuttleK()
        viewModelScope.launch {
            val file = exportEngine.exportSequenceToMp4(_sequence.value)
            if (file != null) {
                _statusBanner.value = "MP4 Export Complete: ${file.name}"
            }
        }
    }

    fun getPrimarySelectedClip(): TimelineClip? {
        val id = _selectedClipIds.value.firstOrNull() ?: return null
        return findClipById(id)
    }

    fun findClipById(clipId: String): TimelineClip? {
        return _sequence.value.tracks.asSequence().flatMap { it.clips }.firstOrNull { it.id == clipId }
    }

    fun undo() {
        if (undoStack.isEmpty()) {
            _statusBanner.value = "Nothing to Undo"
            return
        }
        redoStack.addLast(_sequence.value)
        _sequence.value = undoStack.removeLast()
        _statusBanner.value = "Undo (Ctrl+Z)"
    }

    fun redo() {
        if (redoStack.isEmpty()) {
            _statusBanner.value = "Nothing to Redo"
            return
        }
        undoStack.addLast(_sequence.value)
        _sequence.value = redoStack.removeLast()
        _statusBanner.value = "Redo (Ctrl+Shift+Z)"
    }

    private fun pushUndoSnapshot() {
        if (undoStack.size >= 40) undoStack.removeFirst()
        undoStack.addLast(_sequence.value)
        redoStack.clear()
    }

    private fun snapTimeToPlayheadOrCuts(candidateMs: Long, ignoreClipId: String): Long {
        val thresholdMs = 110L
        if (abs(candidateMs - _playheadMs.value) <= thresholdMs) {
            return _playheadMs.value
        }
        val cutPoints = _sequence.value.tracks
            .flatMap { it.clips }
            .filter { it.id != ignoreClipId }
            .flatMap { listOf(it.timelineStartMs, it.timelineEndMs) }

        for (pt in cutPoints) {
            if (abs(candidateMs - pt) <= thresholdMs) return pt
        }
        return candidateMs
    }

    companion object {
        fun formatTimecode(timeMs: Long, fps: Int = 30): String {
            val clamped = timeMs.coerceAtLeast(0L)
            val totalSeconds = clamped / 1000L
            val hours = totalSeconds / 3600L
            val minutes = (totalSeconds % 3600L) / 60L
            val seconds = totalSeconds % 60L
            val frames = ((clamped % 1000L) * fps) / 1000L
            return String.format("%02d:%02d:%02d:%02d", hours, minutes, seconds, frames)
        }

        private fun createDefaultSourceBin(): List<SourceMonitorAsset> = listOf(
            SourceMonitorAsset(
                id = "src_1",
                name = "A-Roll_Studio_Keynote_4K.mp4",
                durationMs = 6_000L,
                inPointMs = 0L,
                outPointMs = 6_000L,
                defaultTranscriptHint = "Welcome to PulseCut Pro on Android tablet with Cactus Whistle captions"
            ),
            SourceMonitorAsset(
                id = "src_2",
                name = "B-Roll_Timeline_Demo_60fps.mp4",
                durationMs = 6_000L,
                inPointMs = 0L,
                outPointMs = 6_000L,
                defaultTranscriptHint = "Edit faster with Premiere Pro keyboard shortcuts and instant aspect ratio switching"
            ),
            SourceMonitorAsset(
                id = "src_3",
                name = "Vertical_Reel_Cutdown.mp4",
                durationMs = 5_000L,
                inPointMs = 0L,
                outPointMs = 5_000L,
                nativeAspect = AspectRatioPreset.RATIO_9_16,
                defaultTranscriptHint = "Switch from sixteen by nine widescreen to nine by sixteen vertical reels in one tap"
            )
        )

        private fun createInitialDemoSequence(): ProjectSequence {
            val words1 = listOf(
                WhistleWordTimestamp("Welcome", 200L, 680L, 0.99f),
                WhistleWordTimestamp("to", 680L, 920L, 0.99f),
                WhistleWordTimestamp("PulseCut", 920L, 1650L, 0.98f),
                WhistleWordTimestamp("Pro", 1650L, 2200L, 0.99f)
            )
            val words2 = listOf(
                WhistleWordTimestamp("powered", 2300L, 2850L, 0.97f),
                WhistleWordTimestamp("by", 2850L, 3150L, 0.99f),
                WhistleWordTimestamp("Cactus", 3150L, 3950L, 0.99f),
                WhistleWordTimestamp("Whistle", 3950L, 4850L, 0.99f),
                WhistleWordTimestamp("STT", 4850L, 5700L, 0.96f)
            )
            val words3 = listOf(
                WhistleWordTimestamp("with", 6100L, 6550L, 0.98f),
                WhistleWordTimestamp("Premiere", 6550L, 7350L, 0.99f),
                WhistleWordTimestamp("Pro", 7350L, 7850L, 0.99f),
                WhistleWordTimestamp("shortcuts", 7850L, 8900L, 0.97f)
            )
            val words4 = listOf(
                WhistleWordTimestamp("and", 9000L, 9400L, 0.99f),
                WhistleWordTimestamp("multi-aspect", 9400L, 10450L, 0.96f),
                WhistleWordTimestamp("rich", 10450L, 11050L, 0.98f),
                WhistleWordTimestamp("typography!", 11050L, 11850L, 0.99f)
            )

            val cap1 = CaptionSegmentSpec.fromPreset(
                rawText = "Welcome to PulseCut Pro",
                language = "en",
                words = words1,
                preset = CaptionStylePreset.HORMOZI_BOLD
            )
            val cap2 = CaptionSegmentSpec.fromPreset(
                rawText = "powered by Cactus Whistle STT",
                language = "en",
                words = words2,
                preset = CaptionStylePreset.HORMOZI_BOLD
            )
            val cap3 = CaptionSegmentSpec.fromPreset(
                rawText = "with Premiere Pro shortcuts",
                language = "en",
                words = words3,
                preset = CaptionStylePreset.KARAOKE_PILL
            )
            val cap4 = CaptionSegmentSpec.fromPreset(
                rawText = "and multi-aspect rich typography!",
                language = "en",
                words = words4,
                preset = CaptionStylePreset.NEON_GLOW
            )

            val heroTitleSpec = RichTextSpec(
                text = "PULSECUT PRO · TABLET NLE",
                fontFamily = EditorFontFamily.MONTSERRAT_HEAVY,
                fontSizeSp = 32f,
                fontWeight = 900,
                normalizedX = 0.5f,
                normalizedY = 0.16f,
                primaryColorArgb = 0xFFFFFFFF,
                secondaryColorArgb = 0xFF00D2FF,
                strokeEnabled = true,
                strokeColorArgb = 0xFF0D0F14,
                strokeWidthPx = 8f,
                backgroundEnabled = true,
                backgroundColorArgb = 0xB8141923,
                backgroundCornerRadiusPx = 18f,
                animationPreset = TextAnimationPreset.FADE_UP_WORDS
            )

            return ProjectSequence(
                name = "Tablet Master Sequence",
                aspectRatio = AspectRatioPreset.RATIO_16_9,
                canvasScalingMode = CanvasScalingMode.BLUR_BACKDROP,
                fps = 30,
                markers = listOf(
                    SequenceMarker("m1", 0L, "Intro Hook"),
                    SequenceMarker("m2", 6000L, "B-Roll Cut")
                ),
                tracks = listOf(
                    TimelineTrack(
                        id = "T1",
                        name = "T1 · Rich Text",
                        type = TrackType.TEXT,
                        heightDp = 50,
                        clips = listOf(
                            TimelineClip(
                                id = "clip_title_1",
                                name = "PULSECUT PRO · TABLET NLE",
                                trackId = "T1",
                                trackType = TrackType.TEXT,
                                timelineStartMs = 0L,
                                durationMs = 5_800L,
                                textData = heroTitleSpec
                            )
                        )
                    ),
                    TimelineTrack(
                        id = "C1",
                        name = "C1 · Whistle Captions",
                        type = TrackType.CAPTION,
                        heightDp = 54,
                        clips = listOf(
                            TimelineClip(
                                id = "clip_cap_1",
                                name = cap1.rawText,
                                trackId = "C1",
                                trackType = TrackType.CAPTION,
                                timelineStartMs = 150L,
                                durationMs = 2_100L,
                                captionData = cap1,
                                textData = cap1.richStyle
                            ),
                            TimelineClip(
                                id = "clip_cap_2",
                                name = cap2.rawText,
                                trackId = "C1",
                                trackType = TrackType.CAPTION,
                                timelineStartMs = 2_250L,
                                durationMs = 3_550L,
                                captionData = cap2,
                                textData = cap2.richStyle
                            ),
                            TimelineClip(
                                id = "clip_cap_3",
                                name = cap3.rawText,
                                trackId = "C1",
                                trackType = TrackType.CAPTION,
                                timelineStartMs = 6_000L,
                                durationMs = 2_950L,
                                captionData = cap3,
                                textData = cap3.richStyle
                            ),
                            TimelineClip(
                                id = "clip_cap_4",
                                name = cap4.rawText,
                                trackId = "C1",
                                trackType = TrackType.CAPTION,
                                timelineStartMs = 8_950L,
                                durationMs = 3_000L,
                                captionData = cap4,
                                textData = cap4.richStyle
                            )
                        )
                    ),
                    TimelineTrack(
                        id = "V1",
                        name = "V1 · Main Video",
                        type = TrackType.VIDEO,
                        heightDp = 64,
                        clips = listOf(
                            TimelineClip(
                                id = "clip_vid_1",
                                name = "A-Roll_Studio_Keynote_4K.mp4",
                                trackId = "V1",
                                trackType = TrackType.VIDEO,
                                timelineStartMs = 0L,
                                durationMs = 6_000L,
                                spokenTranscriptHint = "Welcome to PulseCut Pro powered by Cactus Whistle STT"
                            ),
                            TimelineClip(
                                id = "clip_vid_2",
                                name = "B-Roll_Timeline_Demo_60fps.mp4",
                                trackId = "V1",
                                trackType = TrackType.VIDEO,
                                timelineStartMs = 6_000L,
                                durationMs = 6_000L,
                                spokenTranscriptHint = "with Premiere Pro shortcuts and multi-aspect rich typography!"
                            )
                        )
                    ),
                    TimelineTrack(
                        id = "A1",
                        name = "A1 · Dialogue 16kHz",
                        type = TrackType.AUDIO,
                        heightDp = 52,
                        clips = listOf(
                            TimelineClip(
                                id = "clip_aud_1",
                                name = "Voiceover_16kHz_Mono.wav",
                                trackId = "A1",
                                trackType = TrackType.AUDIO,
                                timelineStartMs = 0L,
                                durationMs = 12_000L,
                                waveformPeaks = List(60) { i ->
                                    0.25f + 0.65f * kotlin.math.abs(kotlin.math.sin(i * 0.55f))
                                }
                            )
                        )
                    )
                )
            )
        }
    }
}
